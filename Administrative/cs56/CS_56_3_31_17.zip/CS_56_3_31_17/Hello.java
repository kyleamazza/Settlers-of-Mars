import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.geometry.HPos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
public class Hello extends Application {
        public Button btOK;
 
       public void start(Stage primaryStage) {
          
        btOK = new Button("OK");
       Scene scene = new Scene(btOK, 200, 250);
       primaryStage.setTitle("Hello"); 
	   btOK.setOnAction( e -> sayHello());// Set the stage title
       primaryStage.setScene(scene); // Place the scene in the stage
       primaryStage.show(); 
 
       }
	   public void sayHello()
	   {
		   
		   btOK.setText("Hi...");
		   
	   }
	   public static void main(String [] args)
	   {
		   launch(args);
	   }
}