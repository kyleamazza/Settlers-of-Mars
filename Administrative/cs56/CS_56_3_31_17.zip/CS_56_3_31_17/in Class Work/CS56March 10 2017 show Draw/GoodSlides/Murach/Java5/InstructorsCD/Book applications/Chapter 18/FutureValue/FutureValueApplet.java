import java.awt.*;
import javax.swing.*;

public class FutureValueApplet extends JApplet
{
    public void init()
    {
        JPanel panel = new FutureValuePanel();
        this.add(panel);
    }
}