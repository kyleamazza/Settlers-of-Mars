// classes for working with a document
import javax.xml.parsers.*;           // DocumentBuilderFactory, DocumentBuilder, ParserConfigurationException
import org.w3c.dom.*;                 // Document, Element, Text, NodeList

// classes for writing a document
import javax.xml.transform.*;         // Transformer, TransformerConfigurationException, TransformerException, OutputKeys
import javax.xml.transform.dom.*;     // DOMSource
import javax.xml.transform.stream.*;  // StreamResult

// classes for reading a document
import org.xml.sax.*;                 // InputSource, SAXException
import java.io.*;                     // IOException

import java.util.*;                   // ArrayList

public class XMLTesterApp
{
    private static String productsFilename = null;

    public static void main(String args[])
    {
        productsFilename = "products.xml";

        Document productsDoc = readProductsDoc();
        printProductsDoc(productsDoc);

        Product p = new Product("test", "XML Tester", 77.77);

        addProduct(productsDoc, p);
        printProductsDoc(productsDoc);

        deleteProduct(productsDoc, p);
        printProductsDoc(productsDoc);

        writeProductsDoc(productsDoc);
    }

    public static Document readProductsDoc()
    {
        try
        {
            // specify the XML file
            InputSource inputFile = new InputSource(productsFilename);

            // get the DocumentBuilderFactory object and set its properties
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setIgnoringComments(true);

            // get the DocumentBuilder object and read the XML file
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.parse(inputFile);

            System.out.println("The XML document has been read from the " + productsFilename + " file.\n");

            return doc;

        }
        catch(ParserConfigurationException pce)
        {
            pce.printStackTrace();
            return null;
        }
        catch(SAXException se)
        {
            se.printStackTrace();
            return null;
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
            return null;
        }
    }

    public static void printProductsDoc(Document doc)
    {
        System.out.println("Products list: ");

        Element root = doc.getDocumentElement();
        NodeList productsList = root.getElementsByTagName("Product");
        for (int i = 0; i < productsList.getLength(); i++)
        {
            Element productElement = (Element) productsList.item(i);

            String code = productElement.getAttribute("Code");

            NodeList descriptionList =
                productElement.getElementsByTagName("Description");
            Element descriptionElement = (Element) descriptionList.item(0);
            Text descriptionText = (Text) descriptionElement.getFirstChild();
            String description = descriptionText.getNodeValue();

            NodeList priceList = productElement.getElementsByTagName("Price");
            Element priceElement = (Element) priceList.item(0);
            Text priceText = (Text) priceElement.getFirstChild();
            String priceString = priceText.getNodeValue();
            double price = Double.parseDouble(priceString);

            Product p = new Product(code, description, price);
            printProduct(p);
        }

        System.out.println();
    }

    private static void printProduct(Product p)
    {
        String productString =
            StringUtils.padWithSpaces(p.getCode(), 8) +
            StringUtils.padWithSpaces(p.getDescription(), 44) +
            p.getFormattedPrice();

        System.out.println(productString);
    }

    public static void addProduct(Document doc, Product p)
    {
        Element root = doc.getDocumentElement();

        // create and append a child element
        Element newProductElement = doc.createElement("Product");
        root.appendChild(newProductElement);

        // set an attribute
        newProductElement.setAttribute("Code", p.getCode());

        // create and append an element that contains text
        Element descriptionElement = doc.createElement("Description");
        newProductElement.appendChild(descriptionElement);
        Text descriptionText = doc.createTextNode("Description");
        descriptionText.setNodeValue(p.getDescription());
        descriptionElement.appendChild(descriptionText);

        // create and append another element that contains text
        Element priceElement = doc.createElement("Price");
        newProductElement.appendChild(priceElement);
        Text priceText = doc.createTextNode("Price");
        priceText.setNodeValue(Double.toString(p.getPrice()));
        priceElement.appendChild(priceText);

        System.out.println(p.getDescription() + " has been added to the XML document.\n");
    }

    public static void deleteProduct(Document doc, Product p)
    {
        Element root = doc.getDocumentElement();
        NodeList pList = root.getElementsByTagName("Product");
        for (int i = 0; i < pList.getLength(); i++)
        {
            Element pe = (Element) pList.item(i);
            String code = pe.getAttribute("Code");
            if (code.equals(p.getCode()))
            {
                root.removeChild(pe);
                i--;
            }
        }
        System.out.println(p.getDescription() + " has been deleted from the XML document.\n");
    }

    public static void writeProductsDoc(Document doc)
    {
        try
        {
            // prepare the input source (the DOM document)
            DOMSource inputDoc = new DOMSource(doc);

            // prepare the output file
            StreamResult outputFile = new StreamResult(productsFilename);

            // write the DOM document to the file
            TransformerFactory tFactory = TransformerFactory.newInstance();
            Transformer t = tFactory.newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");

            t.transform(inputDoc, outputFile);

            System.out.println("The XML document has been written to the " + productsFilename + " file.\n");
        }
        catch(TransformerConfigurationException tce)
        {
            tce.printStackTrace();
        }
        catch(TransformerException te)
        {
            te.printStackTrace();
        }
    }
}