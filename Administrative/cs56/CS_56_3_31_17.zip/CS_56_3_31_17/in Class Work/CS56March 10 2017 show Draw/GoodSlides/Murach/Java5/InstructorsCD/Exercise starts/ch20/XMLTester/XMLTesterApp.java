// classes for working with a document
import javax.xml.parsers.*;           // DocumentBuilderFactory, DocumentBuilder, ParserConfigurationException
import org.w3c.dom.*;                 // Document, Element, Text, NodeList

// classes for writing a document
import javax.xml.transform.*;         // Transformer, TransformerConfigurationException, TransformerException, OutputKeys
import javax.xml.transform.dom.*;     // DOMSource
import javax.xml.transform.stream.*;  // StreamResult

// classes for reading a document
import org.xml.sax.*;                 // InputSource, SAXException
import java.io.*;                     // IOException

public class XMLTesterApp
{
    private static String productsFilename = null;

    public static void main(String args[])
    {
        productsFilename = "products.xml";

        Document productsDoc = readProductsDoc();
        printProductsDoc(productsDoc);

        Product p = new Product("test", "XML Tester", 77.77);

        addProduct(productsDoc, p);
        printProductsDoc(productsDoc);

        deleteProduct(productsDoc, p);
        printProductsDoc(productsDoc);

        writeProductsDoc(productsDoc);
    }

    public static Document readProductsDoc()
    {
        // add code that reads the XML document from the products.xml file

        System.out.println("The XML document has been read from the " + productsFilename + " file.\n");

        return null;
    }

    public static void printProductsDoc(Document doc)
    {
        System.out.println("Products list: ");

        // add code that prints the products in the XML document to the console
        // using the printProduct method shown below

        System.out.println();
    }

    private static void printProduct(Product p)
    {
        String productString =
            StringUtils.padWithSpaces(p.getCode(), 8) +
            StringUtils.padWithSpaces(p.getDescription(), 44) +
            p.getFormattedPrice();

        System.out.println(productString);
    }

    public static void addProduct(Document doc, Product p)
    {
        // add code that adds a product to the XML document

        System.out.println(p.getDescription() + " has been added to the XML document.\n");
    }

    public static void deleteProduct(Document doc, Product p)
    {
        // add code that deletes the specified product from the XML document

        System.out.println(p.getDescription() + " has been deleted from the XML document.\n");
    }

    public static void writeProductsDoc(Document doc)
    {
        // add code that writes the XML document to the products.xml file

        System.out.println("The XML document has been written to the " + productsFilename + " file.\n");
    }
}