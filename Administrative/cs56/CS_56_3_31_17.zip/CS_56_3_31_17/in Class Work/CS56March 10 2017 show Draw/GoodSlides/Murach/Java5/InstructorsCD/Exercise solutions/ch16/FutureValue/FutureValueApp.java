import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.text.*;

public class FutureValueApp
{
    public static void main(String[] args)
    {
        JFrame frame = new FutureValueFrame();
        frame.setVisible(true);
    }
}

class FutureValueFrame extends JFrame
{
    public FutureValueFrame()
    {
        setTitle("Future Value Calculator");
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new FutureValuePanel();
        this.add(panel);
        this.pack();
        centerWindow(this);
    }

    private void centerWindow(Window w)
    {
        Toolkit tk = Toolkit.getDefaultToolkit();
        Dimension d = tk.getScreenSize();
        setLocation((d.width-w.getWidth())/2, (d.height-w.getHeight())/2);
    }
}

class FutureValuePanel extends JPanel implements ActionListener
{
    private JTextField  paymentTextField,
                        rateTextField;
    private JComboBox   yearsComboBox;
    private JList       futureValueList;
    private JLabel      paymentLabel,
                        rateLabel,
                        yearsLabel,
                        futureValueLabel;
    private JButton     calculateButton,
                        exitButton;
    private DefaultListModel futureValueListModel;

    public FutureValuePanel()
    {
        setLayout(new GridBagLayout());

        // payment label
        paymentLabel = new JLabel("Monthly Payment:");
        add(paymentLabel, getConstraints(0,0,1,1, GridBagConstraints.EAST));

        // payment text field
        paymentTextField = new JTextField(10);
        add(paymentTextField, getConstraints(1,0,1,1, GridBagConstraints.WEST));

        // rate label
        rateLabel = new JLabel("Yearly Interest Rate:");
        add(rateLabel, getConstraints(0,1,1,1, GridBagConstraints.EAST));

        // rate text field
        rateTextField = new JTextField(10);
        add(rateTextField, getConstraints(1,1,1,1, GridBagConstraints.WEST));

        // years label
        yearsLabel = new JLabel("Number of Years:");
        add(yearsLabel, getConstraints(0,2,1,1, GridBagConstraints.EAST));

        // years combo box
        yearsComboBox = new JComboBox();
        for (int year = 1; year <= 20; year++)
            yearsComboBox.addItem(year);
        add(yearsComboBox, getConstraints(1,2,1,1, GridBagConstraints.WEST));

        // future value label
        futureValueLabel = new JLabel("Future Value:");
        add(futureValueLabel, getConstraints(0,3,1,1, GridBagConstraints.EAST));

        // future value list
        futureValueListModel = new DefaultListModel();
        futureValueList = new JList(futureValueListModel);
        futureValueList.setFixedCellWidth(200);
        futureValueList.setVisibleRowCount(5);
        JScrollPane futureValueScrollPane = new JScrollPane(futureValueList,
            ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
            ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        add(futureValueScrollPane, getConstraints(1,3,1,1, GridBagConstraints.WEST));

        // button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));

        // calculate button
        calculateButton = new JButton("Calculate");
        calculateButton.addActionListener(this);
        buttonPanel.add(calculateButton);

        // exit button
        exitButton = new JButton("Exit");
        exitButton.addActionListener(this);
        buttonPanel.add(exitButton);

        add(buttonPanel, getConstraints(1,4,1,1, GridBagConstraints.WEST));
    }

    // a method for setting grid bag constraints
    private GridBagConstraints getConstraints(int gridx, int gridy,
    int gridwidth, int gridheight, int anchor)
    {
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);
        c.ipadx = 5;
        c.gridx = gridx;
        c.gridy = gridy;
        c.gridwidth = gridwidth;
        c.gridheight = gridheight;
        c.anchor = anchor;
        return c;
    }

    public void actionPerformed(ActionEvent e)
    {
        Object source = e.getSource();
        if (source == exitButton)
            System.exit(0);
        else if (source == calculateButton)
        {
            double payment = Double.parseDouble(paymentTextField.getText());
            double rate = Double.parseDouble(rateTextField.getText());
            int years = (Integer)yearsComboBox.getSelectedItem();
            NumberFormat currency = NumberFormat.getCurrencyInstance();
            double futureValue;
            String s;
            futureValueListModel.clear();
            for (int i = 1; i <= years; i++)
            {
                futureValue = FinancialCalculations.calculateFutureValue(
                    payment, rate, i);
                s = "Year " + i + ": " + currency.format(futureValue);
                futureValueListModel.addElement(s);
            }
        }
    }


}
