import java.awt.*;
import javax.swing.*;

public class PaymentApplet extends JApplet
{
    public void init()
    {
        JPanel panel = new PaymentPanel();
        this.add(panel);
    }
}