public class UsedBook extends Book
{
    public String getDisplayText()
    {
    }

    // code would go here
}