public class NoSuchCustomerException extends Exception
{
	private int custNo;

	public NoSuchCustomerException()
	{
	}

	public NoSuchCustomerException(int custNo)
	{
   		super("The customer " + custNo + " does not exist.");
		this.custNo = custNo;
	}

	public int getCustomerNumber()
	{
		return custNo;
	}

}