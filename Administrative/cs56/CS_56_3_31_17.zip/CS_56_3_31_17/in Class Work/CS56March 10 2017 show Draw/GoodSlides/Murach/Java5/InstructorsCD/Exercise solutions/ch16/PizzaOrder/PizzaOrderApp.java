import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.text.*;
import javax.swing.border.*;

public class PizzaOrderApp
{
    public static void main(String[] args)
    {
        JFrame frame = new PizzaOrderFrame();
        frame.setVisible(true);
    }
}

class PizzaOrderFrame extends JFrame
{
    public PizzaOrderFrame()
    {
        setTitle("Pizza Calculator");
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new PizzaOrderPanel();
        this.add(panel);
        this.pack();
        centerWindow(this);
    }

    private void centerWindow(Window w)
    {
        Toolkit tk = Toolkit.getDefaultToolkit();
        Dimension d = tk.getScreenSize();
        setLocation((d.width-w.getWidth())/2, (d.height-w.getHeight())/2);
    }
}

class PizzaOrderPanel extends JPanel implements ActionListener
{
    private JRadioButton smallRadioButton,
                         mediumRadioButton,
                         largeRadioButton;
    private JCheckBox    sausageCheckBox,
                         pepperoniCheckBox,
                         salamiCheckBox,
                         olivesCheckBox,
                         mushroomsCheckBox,
                         anchoviesCheckBox;
    private JLabel       priceLabel;
    private JTextField   priceTextField;
    private JButton      calculateButton,
                         exitButton;

    public PizzaOrderPanel()
    {
        setLayout(new GridBagLayout());

        // size panel
        smallRadioButton = new JRadioButton("Small", true);
        mediumRadioButton = new JRadioButton("Medium");
        largeRadioButton = new JRadioButton("Large");
        ButtonGroup sizeGroup = new ButtonGroup();
        sizeGroup.add(smallRadioButton);
        sizeGroup.add(mediumRadioButton);
        sizeGroup.add(largeRadioButton);
        JPanel sizePanel = new JPanel();
        Border sizeBorder = BorderFactory.createEtchedBorder();
        sizeBorder = BorderFactory.createTitledBorder(sizeBorder, "Size");
        sizePanel.setBorder(sizeBorder);
        sizePanel.add(smallRadioButton);
        sizePanel.add(mediumRadioButton);
        sizePanel.add(largeRadioButton);
        add(sizePanel, getConstraints(0,0,2,1, GridBagConstraints.WEST));

        // toppings panel
        sausageCheckBox = new JCheckBox("Sausage");
        pepperoniCheckBox = new JCheckBox("Pepperoni");
        salamiCheckBox = new JCheckBox("Salami");
        olivesCheckBox = new JCheckBox("Olives");
        mushroomsCheckBox = new JCheckBox("Mushrooms");
        anchoviesCheckBox = new JCheckBox("Anchovies");

        JPanel toppingsPanel = new JPanel();
        toppingsPanel.setLayout(new GridBagLayout());
        Border toppingsBorder = BorderFactory.createEtchedBorder();
        toppingsBorder = BorderFactory.createTitledBorder(toppingsBorder, "Toppings");
        toppingsPanel.setBorder(toppingsBorder);
        toppingsPanel.add(sausageCheckBox, getConstraints(0,0,1,1, GridBagConstraints.WEST));
        toppingsPanel.add(pepperoniCheckBox, getConstraints(0,1,1,1, GridBagConstraints.WEST));
        toppingsPanel.add(salamiCheckBox, getConstraints(0,2,1,1, GridBagConstraints.WEST));
        toppingsPanel.add(olivesCheckBox, getConstraints(1,0,1,1, GridBagConstraints.WEST));
        toppingsPanel.add(mushroomsCheckBox, getConstraints(1,1,1,1, GridBagConstraints.WEST));
        toppingsPanel.add(anchoviesCheckBox, getConstraints(1,2,1,1, GridBagConstraints.WEST));
        add(toppingsPanel, getConstraints(0,1,2,1, GridBagConstraints.WEST));

        // price label
        priceLabel = new JLabel("Price:");
        add(priceLabel, getConstraints(0,2,1,1, GridBagConstraints.EAST));

        // price text box
        priceTextField = new JTextField(10);
        priceTextField.setEditable(false);
        add(priceTextField, getConstraints(1,2,1,1, GridBagConstraints.WEST));

        // button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));

        // calculate button
        calculateButton = new JButton("Calculate");
        calculateButton.addActionListener(this);
        buttonPanel.add(calculateButton);

        // exit button
        exitButton = new JButton("Exit");
        exitButton.addActionListener(this);
        buttonPanel.add(exitButton);

        add(buttonPanel, getConstraints(1,3,1,1, GridBagConstraints.WEST));
    }

    // a method for setting grid bag constraints
    private GridBagConstraints getConstraints(int gridx, int gridy,
    int gridwidth, int gridheight, int anchor)
    {
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);
        c.ipadx = 5;
        c.gridx = gridx;
        c.gridy = gridy;
        c.gridwidth = gridwidth;
        c.gridheight = gridheight;
        c.anchor = anchor;
        return c;
    }

    public void actionPerformed(ActionEvent e)
    {
        Object source = e.getSource();
        if (source == exitButton)
            System.exit(0);
        else if (source == calculateButton)
        {
            double price = 0;
            if (smallRadioButton.isSelected())
                price = 6.99;
            else if (mediumRadioButton.isSelected())
                price = 8.99;
            else if (largeRadioButton.isSelected())
                price = 10.99;
            if (sausageCheckBox.isSelected())
                price += 1.49;
            if (pepperoniCheckBox.isSelected())
                price += 1.49;
            if (salamiCheckBox.isSelected())
                price += 1.49;
            if (olivesCheckBox.isSelected())
                price += 0.99;
            if (mushroomsCheckBox.isSelected())
                price += 0.99;
            if (anchoviesCheckBox.isSelected())
                price += 0.99;
            NumberFormat currency = NumberFormat.getCurrencyInstance();
            priceTextField.setText(currency.format(price));
        }
    }


}
