public class InvoiceApp
{
    public static void main(String[] args)
    {
    }
}

