import java.lang.Math;
import java.util.ArrayList;

public class NumberFinderMonitorApp
{
    public static void main(String args[])
    {
        int target = (int) (Math.random() * 1000);
        System.out.println("The number is " + target);

        Monitor m = new Monitor();                      // create and start the monitor thread
        m.start();

        Thread t1 = new Thread(new Finder(target, 0, 249, m));      // create the Finder threads
        Thread t2 = new Thread(new Finder(target, 250, 499, m));
        Thread t3 = new Thread(new Finder(target, 500, 749, m));
        Thread t4 = new Thread(new Finder(target, 750, 999, m));

        m.addThread(t1);                                // add the Finder threads to the monitor
        m.addThread(t2);
        m.addThread(t3);
        m.addThread(t4);

        t1.start();                                     // start the Finder threads
        t2.start();
        t3.start();
        t4.start();
    }
}

class Monitor extends Thread
{
    private boolean numberFound = false;
    private ArrayList<Thread> threads = new ArrayList<Thread>();

    public void addThread(Thread t)
    {
        threads.add(t);
    }

    public void run()
    {
        while (!numberFound) {}     // loop endlessly until one of the threads finds the number
    }

    public synchronized void foundNumber()
    {
        numberFound = true;
        for (Thread t : threads)
        {
            t.interrupt();
        }
    }
}

class Finder implements Runnable
{
    private int target;
    private int low;
    private int high;
    private Monitor monitor;            // the monitor thread

    public Finder(int target, int low, int high, Monitor m)
    {
        this.target = target;
        this.low = low;
        this.high = high;
        this.monitor = m;
    }

    public void run()
    {
        int sleepCounter = 1;
        Thread t = Thread.currentThread();

        for (int i = this.low; i <= high; i++)
        {
            if (t.interrupted())        // break if interrupted flag is set to true
            {
                System.out.println(t.getName() + " interrupted");
                break;
            }

            if (i == this.target)
            {
                System.out.println("Target number " + target
                    + " found by " + t.getName());
                this.monitor.foundNumber();
                break;
            }
            if (sleepCounter == 10)
            {
                sleepCounter = 1;
                try
                {
                    t.sleep(1);
                }
                catch (InterruptedException e)  // break if InterruptedException is thrown
                {
                    System.out.println(t.getName() + " interrupted");
                    break;
                }
            }
            else
            {
                sleepCounter++;
            }
        }
    }
}