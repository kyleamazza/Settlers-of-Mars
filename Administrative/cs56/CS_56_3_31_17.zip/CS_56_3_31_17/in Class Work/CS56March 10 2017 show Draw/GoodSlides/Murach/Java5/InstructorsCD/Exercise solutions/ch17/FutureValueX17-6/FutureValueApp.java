import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.text.*;

public class FutureValueApp
{
	public static void main(String[] args)
	{
		JFrame frame = new FutureValueFrame();
		frame.setVisible(true);
	}
}

class FutureValueFrame extends JFrame
{
	public FutureValueFrame()
	{
		setTitle("Future Value Calculator");
		setSize(267, 200);
		centerWindow(this);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container contentPane = getContentPane();
		JPanel panel = new FutureValuePanel();
		contentPane.add(panel);
	}

	private void centerWindow(Window w)
	{
		Toolkit tk = Toolkit.getDefaultToolkit();
		Dimension d = tk.getScreenSize();
		setLocation((d.width-w.getWidth())/2, (d.height-w.getHeight())/2);
	}
}

class FutureValuePanel extends JPanel implements ActionListener
{
	private JTextField 	investmentTextField,
						rateTextField,
						yearsTextField,
						futureValueTextField;
	private JLabel 		investmentLabel,
						rateLabel,
						yearsLabel,
						futureValueLabel;
	private JButton 	calculateButton,
						exitButton;

	public FutureValuePanel()
	{
		// display panel
		JPanel displayPanel = new JPanel();
		displayPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));

		// investment label
		investmentLabel = new JLabel("Monthly Investment:");
		displayPanel.add(investmentLabel);

		// investment text field
		investmentTextField = new JTextField(10);
		investmentTextField.addFocusListener(new AutoSelect());
		investmentTextField.addKeyListener(new NumFilter());
		displayPanel.add(investmentTextField);

		// rate label
		rateLabel = new JLabel("Yearly Interest Rate:");
		displayPanel.add(rateLabel);

		// rate text field
		rateTextField = new JTextField(10);
		rateTextField.addFocusListener(new AutoSelect());
		rateTextField.addKeyListener(new NumFilter());
		displayPanel.add(rateTextField);

		// years label
		yearsLabel = new JLabel("Number of Years:");
		displayPanel.add(yearsLabel);

		// years text field
		yearsTextField = new JTextField(10);
		yearsTextField.addFocusListener(new AutoSelect());
		yearsTextField.addKeyListener(new NumFilter());
		displayPanel.add(yearsTextField);

		// future value label
		futureValueLabel = new JLabel("Future Value:");
		displayPanel.add(futureValueLabel);

		// future value text field
		futureValueTextField = new JTextField(10);
		futureValueTextField.setEditable(false);
		futureValueTextField.setFocusable(false);
		displayPanel.add(futureValueTextField);

		// button panel
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));

		// calculate button
		calculateButton = new JButton("Calculate");
		calculateButton.addActionListener(this);
		buttonPanel.add(calculateButton);

		// exit button
		exitButton = new JButton("Exit");
		exitButton.addFocusListener(new AutoSelect());
		exitButton.addActionListener(this);
		buttonPanel.add(exitButton);

		// add panels to frame
		setLayout(new BorderLayout());
		add(displayPanel, BorderLayout.CENTER);
		add(buttonPanel, BorderLayout.SOUTH);
	}

	public void actionPerformed(ActionEvent e)
	{
		Object source = e.getSource();
		if (source == exitButton)
			System.exit(0);
		else if (source == calculateButton)
		{
			if (isValidData())
			{
				double investment = Double.parseDouble(investmentTextField.getText());
				double rate = Double.parseDouble(rateTextField.getText());
				int years = Integer.parseInt(yearsTextField.getText());
				double futureValue = FinancialCalculations.calculateFutureValue(
					investment, rate, years);
				NumberFormat currency = NumberFormat.getCurrencyInstance();
				futureValueTextField.setText(currency.format(futureValue));
			}
		}
	}

	public boolean isValidData()
	{
		return SwingValidator.isPresent(investmentTextField, "Monthly Investment")
			&& SwingValidator.isDouble(investmentTextField, "Monthly Investment")
		    && SwingValidator.isPresent(rateTextField, "Interest Rate")
		    && SwingValidator.isDouble(rateTextField, "Interest Rate")
		    && SwingValidator.isPresent(yearsTextField, "Number of Years")
		    && SwingValidator.isInteger(yearsTextField, "Number of Years");
	}


	public class AutoSelect extends FocusAdapter
	{
		public void focusGained(FocusEvent e)
		{
			if (e.getComponent() instanceof JTextField)
			{
				JTextField t = (JTextField) e.getComponent();
				t.selectAll();
			}
		}
	}

	public class NumFilter extends KeyAdapter
	{
		public void keyTyped(KeyEvent e)
		{
			char c = e.getKeyChar();
			if (   c != '0' && c != '1' && c != '2'
			    && c != '3' && c != '4' && c != '5'
			    && c != '6' && c != '7' && c != '8'
			    && c != '9' && c != '.' && c != '+' && c != '-')
			    e.consume();
		}

	}
}
