import java.util.Scanner;

public class DisplayableTestApp
{
    public static void main(String args[])
    {
        System.out.println("Welcome to the Displayable Test application\n");

        // create an Employee object
        Displayable emp = new Employee(2, "Smith", "John", 50000);

        // display the employee information
        System.out.println(emp.getDisplayText());

        System.out.println();

        // create a Product object
        Displayable prod = new Product("java", "Murach's Beginning Java 2", 49.50);

        // display the product information
        System.out.println(prod.getDisplayText());
    }
}