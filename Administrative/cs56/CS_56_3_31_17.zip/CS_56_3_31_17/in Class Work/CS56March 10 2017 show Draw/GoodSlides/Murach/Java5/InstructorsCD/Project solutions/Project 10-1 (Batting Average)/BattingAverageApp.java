import java.util.Scanner;
import java.text.NumberFormat;

public class BattingAverageApp
{

	static Scanner sc = new Scanner(System.in);				// get a scanner

	public static void main(String[] args)
	{

		NumberFormat nf = NumberFormat.getNumberInstance();	// get a number formatter
		nf.setMinimumFractionDigits(3);						// set it to three decimal digits
		nf.setMaximumFractionDigits(3);

		System.out.println("Welcome to the Batting Average Calculator.");

		do
		{
			int atBats = getAtBats();			// get the number of at bats to process

			System.out.println("\n0 = out, 1 = single, 2 = double, 3 = triple, 4 = home run");

			int[] results = new int[atBats];	// create the results array

			for (int i = 0; i < atBats; i++)
				results[i] = getResult(i);		// get each at bat result

			int successfulAtBats = 0;			// used to calculate batting average
			int totalBases = 0;					// used to calculate slugging percent

			for (int i = 0; i < atBats; i++)
			{
				if (results[i] > 0)
					successfulAtBats++;			// count the successful at bats
				totalBases += results[i];		// sum the total number of bases reached
			}

			// for the following calculations, must cast one of the operands to double
			// to avoid integer result
			double battingAverage = successfulAtBats / (double)atBats;	// calculate batting average
			double sluggingPercent = totalBases / (double)atBats;		// calculate slugging percentage

			System.out.println("\nBatting average: " + nf.format(battingAverage));
			System.out.println("Slugging percent: " + nf.format(sluggingPercent) + "\n");
		} while (getAnotherPlayer());
	}

	public static int getAtBats()
	{
		int atBats = 0;
		boolean isValid = false;

		while (!isValid)
		{
			System.out.print("\nEnter number of times at bat: " );
			if (sc.hasNextInt())				// make sure the next token is an integer
			{
				atBats = sc.nextInt();			// discard the entire line if it isn't
				if (atBats > 0)					// make sure it is greater than zero
					isValid = true;
			}
			sc.nextLine();						// discard any remaining data
		}
		return atBats;							// return the at bats
	}

	public static int getResult(int atBat)
	{
		int result = 0;
		boolean isValid = false;

		while (!isValid)
		{
			System.out.print("Result for at-bat " + atBat + ": " );
			if (sc.hasNextInt())				// make sure the next token is an integer
			{
				result = sc.nextInt();			// discard the entire line if it isn't
				if (result >= 0 && result <= 4)	// make sure it is 0, 1, 2, 3, or 4
					isValid = true;
			}
			sc.nextLine();						// discard any remaining data
		}
		return result;							// return the result
	}

	public static boolean getAnotherPlayer()
	{
		System.out.print("Another batter? (y/n): " );

		String choice = sc.next();
		if (choice.equalsIgnoreCase("Y"))
			return true;
		else
			return false;
	}

}