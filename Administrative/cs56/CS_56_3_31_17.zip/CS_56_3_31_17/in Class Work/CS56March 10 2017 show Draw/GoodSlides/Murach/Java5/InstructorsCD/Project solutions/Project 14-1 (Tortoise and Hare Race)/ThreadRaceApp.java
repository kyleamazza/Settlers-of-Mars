public class ThreadRaceApp
{

	static ThreadRunner tortoise = new ThreadRunner("Tortoise", 0, 10);
	static ThreadRunner hare = new ThreadRunner("Hare", 90, 100);

	public static void main(String[] args)

	{
        System.out.println("Get set...Go!");
        tortoise.start();
        hare.start();
    }

    public static synchronized void finished(ThreadRunner t)
    {
		System.out.println("The race is over! The " + t.getRunnerName() + " is the winner.\n");
		if (t == tortoise)
			hare.interrupt();
		else
			tortoise.interrupt();
	}
}







