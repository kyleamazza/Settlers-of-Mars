import java.lang.Math;

public class NumberFinderThreadApp
{
    public static void main(String args[])
    {
        int target = (int) (Math.random() * 1000);
        System.out.println("The number is " + target);
    }

}