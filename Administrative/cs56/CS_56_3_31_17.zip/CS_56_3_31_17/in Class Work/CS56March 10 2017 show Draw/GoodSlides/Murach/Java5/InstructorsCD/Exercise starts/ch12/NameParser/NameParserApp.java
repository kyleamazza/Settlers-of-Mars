import java.util.Scanner;

public class NameParserApp
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);

        System.out.println("Welcome to the name parser.\n");
        System.out.print("Enter a name: ");
    }
}