import java.util.Arrays;

public class ArrayTestApp
{
    public static void main(String[] args)
    {
    }
}
