import java.util.Scanner;

public class DisplayableTestApp
{
    public static void main(String args[])
    {
        System.out.println("Welcome to the Displayable Test application\n");

        // create an Employee object

        // display the employee information

        System.out.println();

        // create a Product object

        // display the product information
    }
}