public interface ProductReader
{
	Product getProduct(String code);
	String getProductsString();
}