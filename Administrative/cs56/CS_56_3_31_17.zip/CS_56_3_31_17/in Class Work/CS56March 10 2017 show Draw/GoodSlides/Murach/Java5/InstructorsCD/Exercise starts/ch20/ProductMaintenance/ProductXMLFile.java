import org.w3c.dom.*;
import java.util.*;

public class ProductXMLFile implements ProductDAO
{
	private String productsFile = null;
	private Document doc = null;
	private Element root = null;
	private NodeList productsList = null;

	public ProductXMLFile()
	{
		productsFile = "products.xml";
		doc = this.getDocument();
		root = doc.getDocumentElement();
		productsList = doc.getElementsByTagName("Product");
	}

	private Document getDocument()
	{
		try
		{
			// read XML document from XML file
			doc = XMLUtil.getDocumentFromFile(productsFile);
			return doc;
		}
		// catch ParserConfigurationException, SAXException, IOException
		catch(Exception e)
		{
			return null;
		}
	}

	public ArrayList<Product> getProducts()
	{
		// declare the products array list
		ArrayList<Product> products = new ArrayList<Product>();

		// create Product objects from the Product elements
		for (int i = 0; i < productsList.getLength(); i++)
		{
			Element productElement = (Element) productsList.item(i);

			String code = productElement.getAttribute("Code");
			String description =
				XMLUtil.getTextNodeValue(productElement, "Description");
			String priceString =
				XMLUtil.getTextNodeValue(productElement, "Price");
			double price = Double.parseDouble(priceString);

			Product p = new Product(code, description, price);
			products.add(p);
		}
		return products;
	}

	public Product getProduct(String code)
	{
		// loop through Product nodes and return Product object if found
		for (int i = 0; i < productsList.getLength(); i++)
		{
			Element productElement = (Element) productsList.item(i);

			String productCode = productElement.getAttribute("Code");
			if (code.equals(productCode))
			{
				String description =
					XMLUtil.getTextNodeValue(productElement, "Description");
				String priceString =
					XMLUtil.getTextNodeValue(productElement, "Price");
				double price = Double.parseDouble(priceString);
				Product product = new Product(code, description, price);
				return product;
			}
		}
		return null;
	}

	private int getProductIndex(String code)
	{
		// loop through Product nodes and return Product index if found
		for (int i = 0; i < productsList.getLength(); i++)
		{
			Element productElement = (Element) productsList.item(i);

			String productCode = productElement.getAttribute("Code");
			if (code.equals(productCode))
			{
				return i;
			}
		}
		return -1;
	}

	private boolean saveProducts()
	{
		try
		{
			// write the XML document to the XML file
			XMLUtil.writeDocumentToFile(productsFile, doc);
			return true;
		}
		// catch ParserConfigurationException, TransformerException
		catch(Exception e)
		{
			return false;
		}
	}

	private Element getElementFromProduct(Product p)
	{
		Element pe = doc.createElement("Product");
		pe.setAttribute("Code", p.getCode());
		XMLUtil.addTextNode(doc, pe, "Description", p.getDescription());
		XMLUtil.addTextNode(doc, pe, "Price", Double.toString(p.getPrice()));
		return pe;
	}

	public boolean addProduct(Product p)
	{
		Element pe = this.getElementFromProduct(p);
		root.appendChild(pe);
		return this.saveProducts();
	}

	public boolean deleteProduct(Product p)
	{
		int i = this.getProductIndex(p.getCode());
		if (i != -1)
		{
			// update the XML document
			Element pe = (Element) productsList.item(i);
			root.removeChild(pe);
			return this.saveProducts();
		}
		else
			return false;
	}

	public boolean updateProduct(Product newProduct)
	{
		int i = this.getProductIndex(newProduct.getCode());
		if (i != -1)
		{
			// update the XML document
			Element oldElement = (Element) productsList.item(i);
			Element newElement = this.getElementFromProduct(newProduct);
			root.replaceChild(newElement, oldElement);
			return this.saveProducts();
		}
		else
			return false;
	}
}