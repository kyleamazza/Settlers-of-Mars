import java.text.NumberFormat;
import java.util.Scanner;

public class DownloadTimeApp
{
    public static void main(String[] args)
    {
        // display a welcome message
        System.out.println("Welcome to the Download Time Estimator\n\n"
                         + "This program calculates how long it will take to \n"
                         + "download a file with a 56K analog modem.");
        System.out.println();  // print a blank line

        Scanner sc = new Scanner(System.in);
		String choice = "y";
        while (!choice.equalsIgnoreCase("n"))
        {
	        // Estimated data transfer rate
        	// "56K" analog modem = 5.2 KB/sec

        	// get the input from the user
        	System.out.print("Enter file size (MB): ");
        	double megabytes = sc.nextDouble();

        	// estimated number of kilobytes/second
        	double kilobytesPerSecond = 5.2;

        	// calculate the number of kilobytes to transfer
        	double kilobytes = megabytes * 1024;

        	// calculate the total number of seconds
        	double totalSecondsDouble = kilobytes / kilobytesPerSecond;

        	// convert to integer division
        	long totalSeconds = Math.round(totalSecondsDouble);
        	long hours = totalSeconds / (60 * 60);
        	long secondsRemainder = totalSeconds % (60 * 60);
        	long minutes = secondsRemainder / 60;
        	long seconds = secondsRemainder % 60;

        	// display the output
        	System.out.println();
        	System.out.println("A \"56K\" modem will take "
            	+ hours + " hours "
            	+ minutes + " minutes "
            	+ seconds + " seconds");
        	System.out.println();

        	// see if the user wants to continue
			System.out.print("Continue? (y/n): ");
			choice = sc.next();
        	System.out.println();
		}

    }
}
