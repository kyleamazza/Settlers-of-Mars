import java.io.*;

public class DAOFile
{
    private File daoFile = null;

    public DAOFile()
    {
        // initialize the daoFile object
        daoFile = new File("dao.txt");
    }

    private void checkFile() throws IOException
    {
        // if the file doesn't exist, create it
        if (!daoFile.exists())
            daoFile.createNewFile();
    }

    public boolean setDAOName(String daoName)
    {
        // overrite the file with the daoName string
        // return a boolean to indicate if the file was created successfully
        // print the stack trace if an IOException is thrown
        PrintWriter out = null;
        try
        {
            this.checkFile();

            out = new PrintWriter(
                  new BufferedWriter(
                  new FileWriter(daoFile)));

            out.print(daoName);
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
            return false;
        }
        finally
        {
            this.close(out);
        }
        return true;
    }

    public String getDAOName()
    {
        // get and return the name string
        // print the stack trace and return null if an IOException is thrown
        BufferedReader in = null;
        try
        {
            this.checkFile();

            in = new BufferedReader(
                 new FileReader(daoFile));

            String daoText = in.readLine();
            return daoText;
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
            return null;
        }
        finally
        {
            this.close(in);
        }
    }

    private void close(Closeable stream)
    {
        try
        {
            if (stream != null)
                stream.close();
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
    }
}