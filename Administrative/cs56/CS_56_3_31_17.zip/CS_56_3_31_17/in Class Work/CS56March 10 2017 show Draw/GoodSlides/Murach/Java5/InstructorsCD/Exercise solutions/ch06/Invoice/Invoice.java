import java.text.*;
public class Invoice
{
    private double subtotal;
    private String type;
    private double discountPercent;
    private double discountAmount;
    private double invoiceTotal;

    public Invoice(double subtotal, String type)
    {
        this.subtotal = subtotal;
        this.type = type;
        setDiscountPercent();
        setDiscountAmount();
        setInvoiceTotal();
    }

    public void setDiscountPercent()
    {
        if (type.equalsIgnoreCase("r"))
        {
            if (subtotal >= 500)
                discountPercent = .2;
            else if (subtotal >= 250 && subtotal < 500)
                discountPercent =.15;
            else if (subtotal >= 100 && subtotal < 500)
                discountPercent =.1;
            else if (subtotal < 100)
                discountPercent =.0;
        }
        else if (type.equalsIgnoreCase("c"))
            discountPercent = .2;
        else
            discountPercent = .05;
    }

    public void setDiscountAmount()
    {
        discountAmount = subtotal * discountPercent;
    }

    public void setInvoiceTotal()
    {
        invoiceTotal = subtotal - discountAmount;
    }

    public String getInvoice()
    {
        NumberFormat currency = NumberFormat.getCurrencyInstance();
        NumberFormat percent = NumberFormat.getPercentInstance();
        String sSubtotal = currency.format(subtotal);
        String sCustomerType = "";
        if (type.equalsIgnoreCase("r"))
            sCustomerType = "Retail";
        else if (type.equalsIgnoreCase("t"))
            sCustomerType = "College";
        String sDiscountPercent = percent.format(discountPercent);
        String sDiscountAmount = currency.format(discountAmount);
        String sInvoiceTotal = currency.format(invoiceTotal);
        String message = "Subtotal:         " + sSubtotal + "\n"
                       + "Customer type:    " + sCustomerType + "\n"
                       + "Discount percent: " + sDiscountPercent + "\n"
                       + "Discount amount:  " + sDiscountAmount + "\n"
                       + "Total:            " + sInvoiceTotal + "\n";
        return message;
    }
}
