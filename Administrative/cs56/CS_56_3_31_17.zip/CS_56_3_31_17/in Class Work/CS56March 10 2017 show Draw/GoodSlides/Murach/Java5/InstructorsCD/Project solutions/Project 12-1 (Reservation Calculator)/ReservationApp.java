import java.util.*;

public class ReservationApp
{

	static Scanner sc = new Scanner(System.in);		// get the scanner

	public static void main(String[] args)
	{

		System.out.println("Welcome to the Reservation Calculator.");
		do
		{
			// get the month, day, and year of the arrival
			int arrMonth = getInt("\nEnter the arrival month (1-12): ");
			int arrDay = getInt("Enter the arrival day (1-31): ");
			int arrYear = getInt("Enter the arrival year: ");

			// calculate dates from the values entered
			GregorianCalendar arrival = new GregorianCalendar(arrYear, arrMonth - 1, arrDay);
			Date arrivalDate = arrival.getTime();

			// get the month, day, and year of the departure
			int depMonth = getInt("\nEnter the departure month (1-12): ");
			int depDay = getInt("Enter the departure day (1-31): ");
			int depYear = getInt("Enter the departure year: ");

			// calculate dates from the values entered
			GregorianCalendar departure = new GregorianCalendar(depYear, depMonth - 1, depDay);
			Date departureDate = departure.getTime();

			// create a reservation object with the dates entered
			Reservation res = new Reservation(arrivalDate, departureDate);

			// display the reservation data
			System.out.println("\n" + res.toString() + "\n");
			System.out.println();
		} while (getAnother());      // asks if the user wants to enter another reservation
	}

	public static int getInt(String prompt)
	{
		int i = 0;
		boolean isValid = false;
		while (!isValid)
		{
			System.out.print(prompt);
			if (sc.hasNextInt())
			{
				i = sc.nextInt();
				isValid = true;
			}
			else
			{
				System.out.println("Incorrect entry. Try again.");
			}
			sc.nextLine();  // discard any other data entered on the line
		}
		return i;
    }

	public static boolean getAnother()
	{
		System.out.print("Another reservation? (y/n): " );
		String choice = sc.nextLine();
		if (choice.equalsIgnoreCase("Y"))
			return true;
		else
			return false;
	}

}