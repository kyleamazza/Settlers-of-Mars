import java.io.*;
import java.util.*;

public class ProductBinaryFile implements ProductDAO
{
	private File productsFile = null;

	public ProductBinaryFile()
	{
		productsFile = new File("products.dat");
	}

	private void checkFile() throws IOException
	{
		// if the file doesn't exist, create it
		if (!productsFile.exists())
			productsFile.createNewFile();
	}

	private boolean saveProducts(ArrayList<Product> products)
	{
		DataOutputStream out = null;
		try
		{
			this.checkFile();

			// open output stream for overwriting
			out = new DataOutputStream(
				  new BufferedOutputStream(
				  new FileOutputStream(productsFile)));

			// write all products in the array list
			// to the file
			for (Product p : products)
			{
				out.writeUTF(p.getCode());
				out.writeUTF(p.getDescription());
				out.writeDouble(p.getPrice());
			}
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
			return false;
		}
		finally
		{
			this.close(out);
		}
		return true;
	}

	private void close(Closeable stream)
	{
		try
		{
			if (stream != null)
				stream.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}

	public ArrayList<Product> getProducts()
	{
		DataInputStream in = null;
		try
		{
			this.checkFile();

			in = new DataInputStream(
				 new BufferedInputStream(
				 new FileInputStream(productsFile)));

			ArrayList<Product> products = new ArrayList<Product>();

			// read products from the file
			// and add them to the array list
			while(in.available() > 0)
			{
				String code = in.readUTF();
				String description = in.readUTF();
				double price = in.readDouble();
				Product p = new Product(code, description, price);
				products.add(p);
			}
			return products;
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
			return null;
		}
		finally
		{
			this.close(in);
		}
	}

	public Product getProduct(String code)
	{
		ArrayList<Product> products = this.getProducts();
		for (Product p : products)
		{
			if (p.getCode().equals(code))
				return p;
		}
		return null;
	}

	public boolean addProduct(Product p)
	{
		ArrayList<Product> products = this.getProducts();
		products.add(p);
		return this.saveProducts(products);
	}

	public boolean deleteProduct(Product p)
	{
		ArrayList<Product> products = this.getProducts();
		products.remove(p);
		return this.saveProducts(products);
	}

	public boolean updateProduct(Product newProduct)
	{
		ArrayList<Product> products = this.getProducts();

		// get the old product and remove it
		Product oldProduct = this.getProduct(newProduct.getCode());
		int i = products.indexOf(oldProduct);
		products.remove(i);

		// add the updated product
		products.add(i, newProduct);

		return this.saveProducts(products);
	}
}