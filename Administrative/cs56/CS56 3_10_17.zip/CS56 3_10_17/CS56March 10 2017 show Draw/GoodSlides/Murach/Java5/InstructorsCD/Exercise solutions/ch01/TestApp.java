public class TestApp
{
    public static void main(String[] args)
    {
        System.out.println(
            "This Java application has run successfully");
    }
}