import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.text.*;

public class InvoiceApp
{
    public static void main(String[] args)
    {
        JFrame frame = new InvoiceFrame();
        frame.setVisible(true);
    }
}

class InvoiceFrame extends JFrame
{
    public InvoiceFrame()
    {
        setTitle("Invoice Total Calculator");
        setSize(250, 200);
        centerWindow(this);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new InvoicePanel();
        this.add(panel);
    }

    private void centerWindow(Window w)
    {
        Toolkit tk = Toolkit.getDefaultToolkit();
        Dimension d = tk.getScreenSize();
        setLocation((d.width-w.getWidth())/2, (d.height-w.getHeight())/2);
    }
}

class InvoicePanel extends JPanel implements ActionListener
{
    private JTextField  subtotalTextField,
                        percentTextField,
                        discountTextField,
                        totalTextField;

    private JLabel      subtotalLabel,
                        percentLabel,
                        discountLabel,
                        totalLabel;

    private JButton     clearButton,
                        calculateButton,
                        exitButton;

    public InvoicePanel()
    {

        //display panel
        JPanel displayPanel = new JPanel();
        displayPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));

        // subtotal label
        subtotalLabel = new JLabel("Subtotal:");
        displayPanel.add(subtotalLabel);

        // subtotal text field
        subtotalTextField = new JTextField(10);
        displayPanel.add(subtotalTextField);

        // percent label
        percentLabel = new JLabel("Discount Percent:");
        displayPanel.add(percentLabel);

        // percent text field
        percentTextField = new JTextField(10);
        percentTextField.setEditable(false);
        percentTextField.setFocusable(false);
        displayPanel.add(percentTextField);

        // discount label
        discountLabel = new JLabel("Discount:");
        displayPanel.add(discountLabel);

        // years text field
        discountTextField = new JTextField(10);
        discountTextField.setEditable(false);
        discountTextField.setFocusable(false);
        displayPanel.add(discountTextField);

        // total label
        totalLabel = new JLabel("Invoice total:");
        displayPanel.add(totalLabel);

        // total text field
        totalTextField = new JTextField(10);
        totalTextField.setEditable(false);
        totalTextField.setFocusable(false);
        displayPanel.add(totalTextField);

        // button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));

        // clear button
        clearButton = new JButton("Clear");
        clearButton.addActionListener(this);
        buttonPanel.add(clearButton);

        // calculate button
        calculateButton = new JButton("Calculate");
        calculateButton.addActionListener(this);
        buttonPanel.add(calculateButton);

        // exit button
        exitButton = new JButton("Exit");
        exitButton.addActionListener(this);
        buttonPanel.add(exitButton);

        // add the panels
        this.setLayout(new BorderLayout());
        this.add(displayPanel, BorderLayout.CENTER);
        this.add(buttonPanel, BorderLayout.SOUTH);
    }

    public void actionPerformed(ActionEvent e)
    {
        Object source = e.getSource();
        if (source == exitButton)
            System.exit(0);
        else if (source == calculateButton)
        {
            try
            {
                double subtotal = Double.parseDouble(subtotalTextField.getText());
                double discountPercent = 0.0;
                if (subtotal >= 200)
                    discountPercent = .2;
                else if (subtotal >= 100)
                    discountPercent = .1;
                else
                    discountPercent = 0.0;
                double discountAmount = subtotal * discountPercent;
                double total = subtotal - discountAmount;
                NumberFormat number = NumberFormat.getNumberInstance();
                percentTextField.setText(number.format(discountPercent));
                NumberFormat currency = NumberFormat.getCurrencyInstance();
                discountTextField.setText(currency.format(discountAmount));
                totalTextField.setText(currency.format(total));
            }
            catch (Exception ex)
            {
                clearFields();
            }
        }
        else if (source == clearButton)
            clearFields();
    }

    private void clearFields()
    {
        subtotalTextField.setText("");
        percentTextField.setText("");
        discountTextField.setText("");
        totalTextField.setText("");
    }
}
