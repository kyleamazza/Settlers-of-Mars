import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.text.*;
import java.lang.Math;

public class PythagoreanApp
{
    public static void main(String[] args)
    {
        JFrame frame = new PythagoreanFrame();
        frame.setVisible(true);
    }
}

class PythagoreanFrame extends JFrame
{
    public PythagoreanFrame()
    {
        setTitle("Right Triangles");
        centerWindow(this);
        setSize(200, 150);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new PythagoreanPanel();
        this.add(panel);
    }

    private void centerWindow(Window w)
    {
        Toolkit tk = Toolkit.getDefaultToolkit();
        Dimension d = tk.getScreenSize();
        setLocation((d.width-w.getWidth())/2, (d.height-w.getHeight())/2);
    }
}

class PythagoreanPanel extends JPanel implements ActionListener
{
    private JTextField  sideATextField,
                        sideBTextField,
                        sideCTextField;
    private JLabel      sideALabel,
                        sideBLabel,
                        sideCLabel;
    private JButton     calculateButton,
                        exitButton;

    public PythagoreanPanel()
    {
        // display panel
        JPanel displayPanel = new JPanel();
        displayPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));

        // side A label
        sideALabel = new JLabel("Side A:");
        displayPanel.add(sideALabel);

        // side A text field
        sideATextField = new JTextField(10);
        displayPanel.add(sideATextField);

        // side B label
        sideBLabel = new JLabel("Side B:");
        displayPanel.add(sideBLabel);

        // side B text field
        sideBTextField = new JTextField(10);
        displayPanel.add(sideBTextField);

        // side C label
        sideCLabel = new JLabel("Side C:");
        displayPanel.add(sideCLabel);

        // side C text field
        sideCTextField = new JTextField(10);
        sideCTextField.setEditable(false);
        sideCTextField.setFocusable(false);
        displayPanel.add(sideCTextField);

        // button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));

        // calculate button
        calculateButton = new JButton("Calculate");
        calculateButton.addActionListener(this);
        buttonPanel.add(calculateButton);

        // exit button
        exitButton = new JButton("Exit");
        exitButton.addActionListener(this);
        buttonPanel.add(exitButton);

        // add panels to main panel
        this.setLayout(new BorderLayout());
        this.add(displayPanel, BorderLayout.CENTER);
        this.add(buttonPanel, BorderLayout.SOUTH);
    }

    public void actionPerformed(ActionEvent e)
    {
        Object source = e.getSource();
        if (source == exitButton)
            System.exit(0);
        else if (source == calculateButton)
        {
            double sideA = Double.parseDouble(sideATextField.getText());
            double sideB = Double.parseDouble(sideBTextField.getText());
            double sumOfSquares = (sideA * sideA) + (sideB * sideB);
            double sideC = Math.sqrt(sumOfSquares);
            NumberFormat nf = NumberFormat.getNumberInstance();
            sideCTextField.setText(nf.format(sideC));
        }
    }
}
