import java.io.*;

public class FinallyTesterApp
{
    public static void main(String[] args)
    {
        System.out.println("In main: calling Method1.");
        try
        {
            Method1();
        }
        catch (NoSuchMethodException e)
        {
            System.out.println("\tIn catch: NoSuchMethodException caught.");
        }
        System.out.println("In main: returned from Method1.");
    }

    public static void Method1() throws NoSuchMethodException
    {
        System.out.println("\tIn Method1: calling Method2.");
        Method2();
        System.out.println("\tIn Method1: returned from Method2.");
    }

    public static void Method2() throws NoSuchMethodException
    {
        System.out.println("\t\tIn Method2: calling Method3.");
        Method3();
        System.out.println("\t\tIn Method2: returned from Method3.");
    }

    public static void Method3() throws NoSuchMethodException
    {
        System.out.println("\t\t\tIn Method3: Entering.");

        //Add try statement here.
        try
        {
            System.out.println("\t\t\t\tIn try: Throwing exception.");
            int x = 0;
            if (x == 0)
                throw new NoSuchMethodException();
            else
                throw new IOException();
        }
        catch (IOException e)
        {
            System.out.println("\t\t\t\tIn catch: IOException caught.");
        }
        finally
        {
            System.out.println("\t\t\t\tIn finally.");
        }

        System.out.println("\t\t\tIn Method3: Exiting.");
    }
}