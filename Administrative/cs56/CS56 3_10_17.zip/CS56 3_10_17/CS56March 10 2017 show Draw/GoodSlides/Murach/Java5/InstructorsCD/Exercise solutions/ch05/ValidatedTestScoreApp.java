import java.util.Scanner;
import java.text.NumberFormat;

public class ValidatedTestScoreApp
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        String choice = "y";
        while (!choice.equalsIgnoreCase("n"))
        {
	        int scoreTotal = 0;
	        int scoreCount = 0;
	        int testScore = 0;
	        int maximumScore = 0;
	        int minimumScore = 100;

    	    // get the number of scores to be entered
    	    int numberOfEntries = getIntWithinRange(sc,
    	    	"Enter the number of test scores to be entered: ", 0, 36);
    	    System.out.println();

    	    for (int i = 1; i <= numberOfEntries; i++)
    	    {
			    testScore = getIntWithinRange(sc,
    	    		"Enter score " + i + ": ", 0, 101);

    	    	scoreCount += 1;
    	    	scoreTotal += testScore;
    	    	maximumScore = Math.max(maximumScore, testScore);
    	    	minimumScore = Math.min(minimumScore, testScore);
			}

    		// display the score count, score total, and average score
    		double averageScore = (double) scoreTotal / (double) scoreCount;

    		NumberFormat number = NumberFormat.getNumberInstance();
    		number.setMaximumFractionDigits(1);

    		String message = "\n" +
    		                 "Score count:   " + scoreCount + "\n"
    		               + "Score total:   " + scoreTotal + "\n"
			               + "Average score: " + number.format(averageScore) + "\n"
			               + "Minimum score: " + minimumScore + "\n"
			               + "Maximum score: " + maximumScore + "\n";
			System.out.println(message);

			// see if the user wants to enter more test scores
			System.out.print("Enter more test scores? (y/n): ");
			choice = sc.next();
			sc.nextLine();
			System.out.println();
		}
	}
	public static int getInt(Scanner sc, String prompt)
    {
        boolean isValid = false;
        int i = 0;
        while (isValid == false)
        {
            System.out.print(prompt);
            if (sc.hasNextInt())
            {
                i = sc.nextInt();
                isValid = true;
            }
            else
            {
                System.out.println("Error! Invalid integer value. Try again.");
            }
            sc.nextLine();  // discard any other data entered on the line
        }
        return i;
    }

    public static int getIntWithinRange(Scanner sc, String prompt,
    int min, int max)
    {
        int i = 0;
        boolean isValid = false;
        while (isValid == false)
        {
            i = getInt(sc, prompt);
            if (i <= min)
                System.out.println(
                    "Error! Number must be greater than " + min + ".");
            else if (i >= max)
                System.out.println(
                    "Error! Number must be less than " + max + ".");
            else
                isValid = true;
        }
        return i;
    }

}