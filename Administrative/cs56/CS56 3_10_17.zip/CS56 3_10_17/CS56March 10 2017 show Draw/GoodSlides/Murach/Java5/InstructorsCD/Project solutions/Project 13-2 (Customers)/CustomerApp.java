import java.util.Scanner;

public class CustomerApp
{
    public static void main(String args[])
    {
        // display a welcome message
        System.out.println("Welcome to the Customer application");
        System.out.println();

        // create the Scanner object
        Scanner sc = new Scanner(System.in);

        // continue until choice isn't equal to "y" or "Y"
        String choice = "y";
        while (choice.equalsIgnoreCase("y"))
        {
            int custNo = Validator.getInt(sc, "Enter a customer number: ");

            try
            {
                Customer cust = CustomerIO.getCustomer(custNo);
                System.out.println("\n" + cust.getNameAndAddress());
            }
            catch (NoSuchCustomerException e)
            {
                System.out.println(e.getMessage());
            }

            choice = Validator.getRequiredString(sc, "\nDisplay another customer? (y/n): ");
            System.out.println();

        }
    }
}