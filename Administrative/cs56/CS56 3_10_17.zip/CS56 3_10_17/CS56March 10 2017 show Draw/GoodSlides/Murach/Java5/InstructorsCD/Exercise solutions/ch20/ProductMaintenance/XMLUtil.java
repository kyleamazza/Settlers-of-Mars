import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.*;
import java.io.*;

public class XMLUtil
{
	public static Document getNewDocument()
	throws ParserConfigurationException
	{
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		return db.newDocument();
	}

	public static Document getDocumentFromFile(String xmlFile)
	throws ParserConfigurationException, SAXException, IOException
	{
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		InputSource in = new InputSource(xmlFile);
		return db.parse(in);
	}

	public static String getTextNodeValue(Element parent, String tagName)
	{
		NodeList list = parent.getElementsByTagName(tagName);
		Element element = (Element) list.item(0);
		Text text = (Text) element.getFirstChild();
		return text.getNodeValue();
	}

	public static void addTextNode(Document doc, Element parent,
	String elementName, String elementValue)
	{
		Element element = doc.createElement(elementName);
		parent.appendChild(element);
		Text text = doc.createTextNode(elementName);
		text.setNodeValue(elementValue);
		element.appendChild(text);
	}

	public static void writeDocumentToFile(String xmlFile, Document doc)
	throws TransformerException {
		DOMSource in = new DOMSource(doc);
		StreamResult out = new StreamResult(xmlFile);
		Transformer transformer =
			TransformerFactory.newInstance().newTransformer();
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		transformer.transform(in, out);
	}
}