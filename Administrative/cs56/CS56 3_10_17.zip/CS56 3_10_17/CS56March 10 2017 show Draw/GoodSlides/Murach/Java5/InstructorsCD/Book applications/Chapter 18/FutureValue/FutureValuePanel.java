import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.text.*;

public class FutureValuePanel extends JPanel implements ActionListener
{
    private JTextField  investmentTextField,
                        rateTextField,
                        yearsTextField,
                        futureValueTextField;
    private JLabel      paymentLabel,
                        rateLabel,
                        yearsLabel,
                        futureValueLabel;
    private JButton     calculateButton;

    public FutureValuePanel()
    {
        // display panel
        JPanel displayPanel = new JPanel();
        displayPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));

        // payment label
        paymentLabel = new JLabel("Monthly Payment:");
        displayPanel.add(paymentLabel);

        // payment text field
        investmentTextField = new JTextField(10);
        displayPanel.add(investmentTextField);

        // rate label
        rateLabel = new JLabel("Yearly Interest Rate:");
        displayPanel.add(rateLabel);

        // rate text field
        rateTextField = new JTextField(10);
        displayPanel.add(rateTextField);

        // years label
        yearsLabel = new JLabel("Number of Years:");
        displayPanel.add(yearsLabel);

        // years text field
        yearsTextField = new JTextField(10);
        displayPanel.add(yearsTextField);

        // future value label
        futureValueLabel = new JLabel("Future Value:");
        displayPanel.add(futureValueLabel);

        // future value text field
        futureValueTextField = new JTextField(10);
        futureValueTextField.setEditable(false);
        futureValueTextField.setFocusable(false);
        displayPanel.add(futureValueTextField);

        // button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));

        // calculate button
        calculateButton = new JButton("Calculate");
        calculateButton.addActionListener(this);
        buttonPanel.add(calculateButton);

        // add panels to frame
        setLayout(new BorderLayout());
        add(displayPanel, BorderLayout.CENTER);
         System.out.println("The display panel has been added..."); // for debugging
        add(buttonPanel, BorderLayout.SOUTH);
         System.out.println("The button banel has been added..."); // for debugging
    }

    public boolean isValidData()
    {
        return SwingValidator.isPresent(investmentTextField, "Monthly Investment")
            && SwingValidator.isDouble(investmentTextField, "Monthly Investment")
            && SwingValidator.isPresent(rateTextField, "Interest Rate")
            && SwingValidator.isDouble(rateTextField, "Interest Rate")
            && SwingValidator.isPresent(yearsTextField, "Number of Years")
            && SwingValidator.isInteger(yearsTextField, "Number of Years");
    }

    public void actionPerformed(ActionEvent e)
    {
        if (isValidData())
        {
            Object source = e.getSource();
            if (source == calculateButton)
            {
                double payment = Double.parseDouble(investmentTextField.getText());
                double rate = Double.parseDouble(rateTextField.getText());
                int years = Integer.parseInt(yearsTextField.getText());
                double futureValue = FinancialCalculations.calculateFutureValue(
                    payment, rate, years);
                NumberFormat currency = NumberFormat.getCurrencyInstance();
                futureValueTextField.setText(currency.format(futureValue));
                 System.out.println("The calculation has been performed..."); // for debugging
            }
        }
    }
}