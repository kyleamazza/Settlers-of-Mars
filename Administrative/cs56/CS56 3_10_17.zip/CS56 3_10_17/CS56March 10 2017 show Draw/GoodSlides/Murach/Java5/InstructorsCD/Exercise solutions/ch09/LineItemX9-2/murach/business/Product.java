package murach.business;

import java.text.NumberFormat;

/**********************************************************
 * The <code>Product</code> class represents a product and is used
 * by the <code>LineItem</code> and <code>ProductDB</code> classes.
 * @author Joel Murach
 * @version 1.0.0
 **********************************************************/
public class Product
{
    private String code;
    private String description;
    private double price;

    /***********************************************************
     * Creates a <code>Product</code> with default values.
     ***********************************************************/
    public Product()
    {
        code = "";
        description = "";
        price = 0;
    }

    /***********************************************************
     * Sets the product code to the specified <code>String</code>.
     *
     * @param code A <code>String</code> for the product code.
     ***********************************************************/
    public void setCode(String code)
    {
        this.code = code;
    }

    /***********************************************************
     * Returns a <code>String</code> that represents the product code.
     *
     * @return A <code>String</code> for the product code.
     ***********************************************************/
    public String getCode(){
        return code;
    }

    /***********************************************************
     * Sets the product description to the specified
     * <code>String</code>.
     *
     * @param description A <code>String</code> for the product
     * description.
     ***********************************************************/
    public void setDescription(String description)
    {
        this.description = description;
    }

    /***********************************************************
     * Returns a <code>String</code> that represents the product
     * description.
     *
     * @return A <code>String</code> for the product description.
     ***********************************************************/
    public String getDescription()
    {
        return description;
    }

    /***********************************************************
     * Sets the product price to the specified
     * <code>double</code> value.
     *
     * @param price A <code>double</code> for the product price.
     ***********************************************************/
    public void setPrice(double price)
    {
        this.price = price;
    }

    /***********************************************************
     * Returns a <code>double</code> value that represents the
     * product price.
     *
     * @return A <code>double</code> for the product price.
     ***********************************************************/
    public double getPrice()
    {
        return price;
    }

    /***********************************************************
     * Returns a <code>String</code> that represents the product
     * price with standard currency formatting applied ($0.00).
     *
     * @return A <code>String</code> for the product price with
     * standard currency formatting applied.
     ***********************************************************/
    public String getFormattedPrice()
    {
        NumberFormat currency = NumberFormat.getCurrencyInstance();
        return currency.format(price);
    }

}