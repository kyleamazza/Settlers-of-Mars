import java.util.Date;
import java.text.*;

public class Reservation
{
	private Date arrivalDate;
	private Date departureDate;

	public static double PRICE_PER_NIGHT = 115.00;

	public Reservation(Date arrival, Date departure)
	{
		this.arrivalDate = arrival;
		this.departureDate = departure;
	}

	public double getTotalPrice()
	{
		int numOfNights = this.getNumOfNights();
		return PRICE_PER_NIGHT * numOfNights;
	}

	public int getNumOfNights()
	{
		long msArrival = arrivalDate.getTime();
		long msDeparture = departureDate.getTime();
		return (int)((msDeparture - msArrival) / (24 * 60 * 60 * 1000));
	}

	public String toString()
	{
		NumberFormat cf = NumberFormat.getCurrencyInstance();
		DateFormat df = DateFormat.getDateInstance(DateFormat.FULL);
		String s = "Arrival Date: " + df.format(arrivalDate) + "\n"
			+ "Departure Date: " + df.format(departureDate) + "\n"
			+ "Price: " + cf.format(PRICE_PER_NIGHT) + " per night\n"
			+ "Total price: " + cf.format(this.getTotalPrice())
			+ " for " + this.getNumOfNights() + " nights";
		return s;
	}
}
