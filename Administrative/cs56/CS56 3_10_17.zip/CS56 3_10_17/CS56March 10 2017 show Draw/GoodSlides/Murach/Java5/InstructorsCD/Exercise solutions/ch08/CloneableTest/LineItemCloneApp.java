import java.util.Scanner;

public class LineItemCloneApp
{
	public static void main(String args[]) throws CloneNotSupportedException
	{
		// welcome the user to the program
		System.out.println("Weclome to the Line Item Clone Test");
		System.out.println();

		// create a new product
		Product p1 = new Product();
		p1.setCode("java");
		p1.setDescription("Murach's Beginning Java 2");
		p1.setPrice(49.50);

		// create a new line item
		LineItem li1 = new LineItem();
		li1.setProduct(p1);
		li1.setQuantity(3);

		// clone the line item
		LineItem li2 = (LineItem) li1.clone();

		// change a value in the cloned line item
		// and in the Product object it contains
		li2.setQuantity(2);
		li2.getProduct().setPrice(44.50);

		if (
			li1.getQuantity() == li2.getQuantity() ||
			li1.getProduct().getPrice() == li2.getProduct().getPrice()
			)
		{
			System.out.println("FAILURE: The clone method of the LineItem class is not cloning data.");
		}
		else if (
			li1.getQuantity() != li2.getQuantity() ||
			li1.getProduct().getPrice() != li2.getProduct().getPrice()
			)
		{
			System.out.println("SUCCESS: The clone method of the LineItem class is cloning data.");
		}

		System.out.println();
	}
}