import java.io.*;

public class FinallyTesterApp
{
    public static void main(String[] args)
    {
        System.out.println("In main: calling Method1.");
        Method1();
        System.out.println("In main: returned from Method1.");
    }

    public static void Method1()
    {
        System.out.println("\tIn Method1: calling Method2.");
        Method2();
        System.out.println("\tIn Method1: returned from Method2.");
    }

    public static void Method2()
    {
        System.out.println("\t\tIn Method2: calling Method3.");
        Method3();
        System.out.println("\t\tIn Method2: returned from Method3.");
    }

    public static void Method3()
    {
        System.out.println("\t\t\tIn Method3: Entering.");

        //Add code to throw an exception here.

        System.out.println("\t\t\tIn Method3: Exiting.");
    }
}