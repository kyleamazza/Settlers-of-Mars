import java.io.*;

public class CustomTesterApp
{
    public static void main(String[] args)
    {
        System.out.println("In main: calling Method1.");
        Method1();
        System.out.println("In main: returned from Method1.");
    }

    public static void Method1()
    {
        System.out.println("\tIn Method1: calling Method2.");
        Method2();
        System.out.println("\tIn Method1: returned from Method2.");
    }

    public static void Method2()
    {
        System.out.println("\t\tIn Method2: calling Method3.");
        try
        {
        Method3();
        }
        catch (TestException e)
        {
            System.out.println("\t\t\tIn catch: " + e.getCause().toString());
        }
        System.out.println("\t\tIn Method2: returned from Method3.");
    }

    public static void Method3() throws TestException
    {
        System.out.println("\t\t\tIn Method3: Entering.");

        //Add code to throw custom exception here.
        try
        {
            throw new IOException();
        }
        catch (IOException e)
        {
            throw new TestException(e);
        }

        //System.out.println("\t\t\tIn Method3: Exiting.");
    }
}