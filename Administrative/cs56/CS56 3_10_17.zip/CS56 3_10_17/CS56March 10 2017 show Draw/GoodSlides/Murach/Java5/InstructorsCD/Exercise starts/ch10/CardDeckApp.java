import java.util.Arrays;

public class CardDeckApp
{
    public static void main(String[] args)
    {
    }
}
