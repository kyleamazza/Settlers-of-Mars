public class OrderQueueApp
{
    public static void main(String[] args)
    {
        final int TAKER_COUNT = 3;     // number of OrderTaker threads
        final int ORDER_COUNT = 3;     // number of orders per OrderTaker thread
        final int HANDLER_COUNT = 2;   // number of OrderHandler threads

        OrderQueue queue = new OrderQueue();      // create the order queue

        System.out.println("Starting the order queue.");
        System.out.println("Starting " + TAKER_COUNT + " order taker threads, "
            + "each producing " + ORDER_COUNT + " orders.");

        for (int i = 0; i < TAKER_COUNT; i++)     // create the OrderTaker threads
        {
            OrderTaker t = new OrderTaker(ORDER_COUNT, queue);
            t.start();
        }

        System.out.println("Starting " + HANDLER_COUNT + " order handler threads.\n");
        for (int i = 0; i < HANDLER_COUNT; i++)   // create the OrderHandler threads
        {
            OrderHandler h = new OrderHandler(queue);
            h.start();
        }

        String s = "     OrderTaker threads     \t     OrderHandler threads    \n"
                 + "============================\t=============================";
        System.out.println(s);

    }
}







