import java.util.Scanner;
import java.text.NumberFormat;

public class EnhancedTestScoreApp
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        String choice = "y";
        while (!choice.equalsIgnoreCase("n"))
        {
	        int scoreTotal = 0;
	        int scoreCount = 0;
	        int testScore = 0;
	        int maximumScore = 0;
	        int minimumScore = 100;

    	    // get the number of scores to be entered
    	    System.out.print("Enter the number of test scores to be entered: ");
    	    int numberOfEntries = sc.nextInt();
    	    System.out.println();

    	    for (int i = 1; i <= numberOfEntries; i++)
    	    {
			    System.out.print("Enter score " + i + ": ");
    	    	testScore = sc.nextInt();

    	    	// accumulate score count and score total
    	    	if (testScore <= 100)
    	    	{
    	    		scoreCount += 1;
    	    		scoreTotal += testScore;
    	    		maximumScore = Math.max(maximumScore, testScore);
    	    		minimumScore = Math.min(minimumScore, testScore);
				}
				else if (testScore != 999)
				{
					System.out.println("Invalid entry, not counted");
					i--;
				}
			}

    		// calculate the average score
    		double averageScore = (double) scoreTotal / (double) scoreCount;

    		// display the results
    		NumberFormat number = NumberFormat.getNumberInstance();
    		number.setMaximumFractionDigits(1);

    		String message = "\n" +
    		                 "Score count:   " + scoreCount + "\n"
    		               + "Score total:   " + scoreTotal + "\n"
			               + "Average score: " + number.format(averageScore) + "\n"
			               + "Minimum score: " + minimumScore + "\n"
			               + "Maximum score: " + maximumScore + "\n";
			System.out.println(message);

			// see if the user wants to enter more test scores
			System.out.print("Enter more test scores? (y/n): ");
			choice = sc.next();
			System.out.println();
		}
	}
}