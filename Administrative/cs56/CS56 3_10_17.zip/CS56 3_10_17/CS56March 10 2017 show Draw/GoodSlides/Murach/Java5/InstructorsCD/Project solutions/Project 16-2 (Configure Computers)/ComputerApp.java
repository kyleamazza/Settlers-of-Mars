import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.lang.Math;
import java.text.NumberFormat;

public class ComputerApp
{
    public static void main(String[] args)
    {
        JFrame frame = new ComputerFrame();
        frame.setVisible(true);
    }
}

class ComputerFrame extends JFrame
{
    public ComputerFrame()
    {
        setTitle("Computer");
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new ComputerPanel();
        this.add(panel);
        this.pack();
        centerWindow(this);
    }

    private void centerWindow(Window w)
    {
        Toolkit tk = Toolkit.getDefaultToolkit();
        Dimension d = tk.getScreenSize();
        setLocation((d.width-w.getWidth())/2, (d.height-w.getHeight())/2);
    }
}

class ComputerPanel extends JPanel implements ActionListener
{

	private JLabel		processorLabel,

						memoryLabel,
						diskLabel,
						priceLabel;

	private JComboBox	processorComboBox,
						memoryComboBox,
						diskComboBox;

	private JRadioButton	homeRadioButton,
							proRadioButton;

	private JCheckBox	officeCheckBox,
						accountingCheckBox,
						graphicsCheckBox;

    private JButton     calculateButton,
                        exitButton;

    private Option[] processor = { new Option("P4 2.2GHz", 0),
    							   new Option("P4 2.4GHz", 50),
    							   new Option("P4 2.6GHz", 150) };

    private Option[] memory = { new Option("256MB RAM", -50),
    							new Option("512MB", 0),
    							new Option("1GB", 50),
    							new Option("2GB", 150) };

    private Option[] disk = { new Option("80GB", 0),
    						  new Option("120GB", 50),
    						  new Option("170GB", 150) };

    private Option xphome = new Option("Windows XP Home Edition", 0);
    private Option xppro  = new Option("Windows XP Professional", 100);
    private Option office = new Option("Office package", 400);
    private Option acct   = new Option("Accounting package", 200);
    private Option graph  = new Option("Graphics package", 600);

    private double basePrice = 500.0;


    public ComputerPanel()
    {

        setLayout(new GridBagLayout());

        Border loweredBorder
            = BorderFactory.createBevelBorder(BevelBorder.LOWERED);

        // hardware panel
        JPanel hardwarePanel = new JPanel();
        hardwarePanel.setLayout(new GridBagLayout());
        hardwarePanel.setBorder(
            BorderFactory.createTitledBorder(loweredBorder,"Hardware"));

        // processor label
        processorLabel = new JLabel("Processor: ");
        hardwarePanel.add(processorLabel, getConstraints(0,0,1,1, GridBagConstraints.EAST));

        // processor combo box
        processorComboBox = new JComboBox(processor);
        processorComboBox.setSelectedIndex(0);
        hardwarePanel.add(processorComboBox, getConstraints(1,0,1,1, GridBagConstraints.WEST));

        // memory label
        memoryLabel = new JLabel("Memory: ");
        hardwarePanel.add(memoryLabel, getConstraints(0,1,1,1, GridBagConstraints.EAST));

        // memory combo box
        memoryComboBox = new JComboBox(memory);
        memoryComboBox.setSelectedIndex(0);
        hardwarePanel.add(memoryComboBox, getConstraints(1,1,1,1, GridBagConstraints.WEST));

        // disk label
        diskLabel = new JLabel("Disk: ");
        hardwarePanel.add(diskLabel, getConstraints(0,2,1,1, GridBagConstraints.EAST));

        // disk combo box
        diskComboBox = new JComboBox(disk);
        diskComboBox.setSelectedIndex(0);
        hardwarePanel.add(diskComboBox, getConstraints(1,2,1,1, GridBagConstraints.WEST));

		add(hardwarePanel, getConstraints(0,0,1,1, GridBagConstraints.NORTH));

        // software panel
        JPanel softwarePanel = new JPanel();
        softwarePanel.setLayout(new GridBagLayout());
        softwarePanel.setBorder(
            BorderFactory.createTitledBorder(loweredBorder,"Software"));


        ButtonGroup xpGroup = new ButtonGroup();

        // windows home radio button
        homeRadioButton = new JRadioButton(xphome.toString(), true);
        xpGroup.add(homeRadioButton);
        softwarePanel.add(homeRadioButton, getConstraints(0,0,1,1, GridBagConstraints.WEST));

        // windows pro radio button
        proRadioButton = new JRadioButton(xppro.toString(), false);
        xpGroup.add(proRadioButton);
        softwarePanel.add(proRadioButton, getConstraints(0,1,1,1, GridBagConstraints.WEST));

        // office package radio button
        officeCheckBox = new JCheckBox(office.toString(), false);
        softwarePanel.add(officeCheckBox, getConstraints(0,2,1,1, GridBagConstraints.WEST));

        // accounting package radio button
        accountingCheckBox = new JCheckBox(acct.toString(), false);
        softwarePanel.add(accountingCheckBox, getConstraints(0,3,1,1, GridBagConstraints.WEST));

        // graphics package radio button
        graphicsCheckBox = new JCheckBox(graph.toString(), false);
        softwarePanel.add(graphicsCheckBox, getConstraints(0,4,1,1, GridBagConstraints.WEST));

        add(softwarePanel, getConstraints(1, 0, 1, 1, GridBagConstraints.NORTH));

        // button panel
        JPanel buttonPanel = new JPanel();

        // calculate button
        calculateButton = new JButton("Calculate");
        calculateButton.addActionListener(this);
        buttonPanel.add(calculateButton);

        // exit button
        exitButton = new JButton("Exit");
        exitButton.addActionListener(this);
        buttonPanel.add(exitButton);

        add(buttonPanel, getConstraints(1, 1, 1, 1, GridBagConstraints.EAST));

        priceLabel = new JLabel(getPrice());
        add(priceLabel, getConstraints(0, 1, 1, 1, GridBagConstraints.EAST));

    }


    // a  method for setting grid bag constraints
    private GridBagConstraints getConstraints(int gridx, int gridy,
    int gridwidth, int gridheight, int anchor)
    {
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);
        c.ipadx = 0;
        c.ipady = 0;
        c.gridx = gridx;
        c.gridy = gridy;
        c.gridwidth = gridwidth;
        c.gridheight = gridheight;
        c.anchor = anchor;
        return c;
    }

    public void actionPerformed(ActionEvent e)
    {
        Object source = e.getSource();
        if (source == exitButton)
            System.exit(0);
        else if (source == calculateButton)
        {
	        priceLabel.setText(getPrice());
		}

    }

    public String getPrice()
    {
		NumberFormat cf = NumberFormat.getCurrencyInstance();

		Option p = (Option) processorComboBox.getSelectedItem();
		Option m = (Option) memoryComboBox.getSelectedItem();
		Option d = (Option) diskComboBox.getSelectedItem();

		double price = this.basePrice;
		price += p.getPrice();
		price += m.getPrice();
		price += d.getPrice();

		if (homeRadioButton.isSelected())
			price += xphome.getPrice();
		else
			price += xppro.getPrice();

		if (officeCheckBox.isSelected())
			price += office.getPrice();

		if (accountingCheckBox.isSelected())
			price += acct.getPrice();

		if (graphicsCheckBox.isSelected())
			price += graph.getPrice();

		return "Price: " + cf.format(price);

	}

}

class Option
{
	private String name;
	private double price;

	public Option(String name, double price)
	{
		this.name = name;
		this.price = price;
	}

	public String toString()
	{
		return this.name;
	}

	public double getPrice()
	{
		return this.price;
	}
}