import java.lang.Math;

public class NumberFinderRunnableApp
{
    public static void main(String args[])
    {
        int target = (int) (Math.random() * 1000);
        System.out.println("The number is " + target);
        Thread t1 = new Thread(new Finder(target, 0, 249));
        Thread t2 = new Thread(new Finder(target, 250, 499));
        Thread t3 = new Thread(new Finder(target, 500, 749));
        Thread t4 = new Thread(new Finder(target, 750, 999));
        t1.start();
        t2.start();
        t3.start();
        t4.start();
    }
}

class Finder implements Runnable
{
    private int target;
    private int low;
    private int high;

    public Finder(int target, int low, int high)
    {
        this.target = target;
        this.low = low;
        this.high = high;
    }

    public void run()
    {
        int sleepCounter = 1;
        Thread t = Thread.currentThread();

        for (int i = this.low; i <= high; i++)
        {
            if (i == this.target)
            {
                System.out.println("Target number " + target
                    + " found by " + t.getName());
                break;
            }
            if (sleepCounter == 10)
            {
                sleepCounter = 1;
                try
                {
                    t.sleep(1);
                }
                catch (InterruptedException e) {}   // ignore any interruptions
            }
            else
            {
                sleepCounter++;
            }
        }
    }
}