import java.io.*;
import java.util.Scanner;


public class ValidFilenameApp
{


    static Scanner sc = new Scanner(System.in);


    public static void main(String[] args)
    {
        System.out.println("Welcome to the File Checker Application.");

        String fileName;

        do
        {
            System.out.print("\nEnter a file path and name: ");
            fileName = sc.nextLine();

            if (doesFileExist(fileName))
                System.out.println("That file exists.\n");
            else
                System.out.println("That file does not exist.\n");

        } while (getAnother());

    }


    public static boolean doesFileExist(String path)
    {
        try
        {
            FileInputStream f = new FileInputStream(path);
            return true;
        }
        catch (FileNotFoundException e)
        {
            return false;
        }
    }

    public static boolean getAnother()
    {
        System.out.print("Check another file? (y/n): " );
        String choice = sc.nextLine();
        if (choice.equalsIgnoreCase("Y"))
            return true;
        else
            return false;
    }

}