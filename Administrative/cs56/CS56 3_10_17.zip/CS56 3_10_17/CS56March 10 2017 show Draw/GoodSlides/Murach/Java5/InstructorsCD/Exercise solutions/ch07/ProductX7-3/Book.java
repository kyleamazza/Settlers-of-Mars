public class Book extends Product
{
    private String author;

    public Book()
    {
        super();
        author = "";
        count++;
    }

    public void setAuthor(String author)
    {
        this.author = author;
    }

    public String getAuthor(){
        return author;
    }

    public String getDisplayText()  // implement the abstract method
    {
        return super.toString() +
            "Author:      " + author + "\n";
    }
}