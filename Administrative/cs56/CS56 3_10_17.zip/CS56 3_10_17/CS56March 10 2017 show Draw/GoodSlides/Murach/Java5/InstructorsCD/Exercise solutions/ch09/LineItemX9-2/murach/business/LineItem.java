package murach.business;

import java.text.NumberFormat;
import murach.business.Product;

/**********************************************************
 * The LineItem class represents a product and is used by
 * the LineItemApp class.
 **********************************************************/
public class LineItem
{
    private Product product;
    private int quantity;
    private double total;

    /***********************************************************
     * Creates a new LineItem with default values.
     ***********************************************************/
    public LineItem()
    {
        this.product = new Product();
        this.quantity = 0;
        this.total = 0;
    }

    /***********************************************************
     * Creates a new LineItem for the specified product and
     * quantity.
     ***********************************************************/
    public LineItem(Product product, int quantity)
    {
        this.product = product;
        this.quantity = quantity;
    }

    /***********************************************************
     * Sets the line item product to the specified Product.
     ***********************************************************/
    public void setProduct(Product product)
    {
        this.product = product;
    }

    /***********************************************************
     * Returns a Product that represents the line item product.
     ***********************************************************/
    public Product getProduct()
    {
        return product;
    }

    /***********************************************************
     * Set the line item quantity to the specified int value.
     ***********************************************************/
    public void setQuantity(int quantity)
    {
        this.quantity = quantity;
    }

    /***********************************************************
     * Returns an int value that represents the line item
     * quantity.
     ***********************************************************/
    public int getQuantity()
    {
        return quantity;
    }

    /***********************************************************
     * Returns a double value that represents the line item
     * total.
     ***********************************************************/
    public double getTotal()
    {
        this.calculateTotal();
        return total;
    }

    /***********************************************************
     * Calculates the line item total.
     ***********************************************************/
    private void calculateTotal()
    {
        total = quantity * product.getPrice();
    }

    /***********************************************************
     * Returns a String that represents the line item total
     * with standard currency formatting applied ($0.00).
     ***********************************************************/
    public String getFormattedTotal()
    {
        NumberFormat currency = NumberFormat.getCurrencyInstance();
        return currency.format(this.getTotal());
    }
}