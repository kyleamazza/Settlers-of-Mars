import java.text.NumberFormat;
import java.util.*;

public class ValidatedInvoiceApp
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        String choice = "y";

        while (!choice.equalsIgnoreCase("n"))
		{
        	// get a valid customer type from the user
        	String customerType = getValidCustomerType(sc);

        	double subtotal = 0.0;
        	try
        	{
				// get a valid subtotal from the user
				subtotal = getValidSubtotal(sc);
			}
			catch(InputMismatchException e)
			{
				System.out.println("InputMismatchException: Check subtotal entry and try again.");
				sc.nextLine();
				continue;
			}

        	// get the discount percent
        	double discountPercent = getDiscountPercent(customerType, subtotal);

        	// calculate the discount amount and total
        	double discountAmount = subtotal * discountPercent;
        	double total = subtotal - discountAmount;

        	// format and display the results
        	NumberFormat currency = NumberFormat.getCurrencyInstance();
        	NumberFormat percent = NumberFormat.getPercentInstance();
        	System.out.println(
        	    "Discount percent: " + percent.format(discountPercent) + "\n" +
        	    "Discount amount:  " + currency.format(discountAmount) + "\n" +
        	    "Total:            " + currency.format(total) + "\n");

        	// see if the user wants to continue
			System.out.print("Continue? (y/n): ");
			choice = sc.next();
			sc.nextLine();
            System.out.println();
		}
	}

	private static double getDiscountPercent(String customerType, double subtotal)
	{
		double discountPercent = 0.0;
		if (customerType.equalsIgnoreCase("R"))
		{
		    if (subtotal < 100)
		        discountPercent = 0;
		    else if (subtotal >= 100 && subtotal < 250)
		        discountPercent = .1;
		    else if (subtotal >= 250 && subtotal < 500)
		        discountPercent = .25;
		    else if (subtotal >= 500)
		    	discountPercent = .3;
		}
		else if (customerType.equalsIgnoreCase("C"))
		{
	   	    discountPercent = .2;
		}
		else if (customerType.equalsIgnoreCase("T"))
		{
			if (subtotal < 500)
				discountPercent = .4;
			else if (subtotal >= 500)
			    discountPercent = .5;
		}
		return discountPercent;
	}

	private static String getValidCustomerType(Scanner sc)
	{
		String customerType = "";
		boolean isValid = false;
		while (isValid == false)
		{
			System.out.print("Enter customer type (r/c/t): ");
		 	customerType = sc.next();
		   	if   (!customerType.equalsIgnoreCase("r")
		   	   && !customerType.equalsIgnoreCase("c")
		   	   && !customerType.equalsIgnoreCase("t"))
		   	{
				System.out.println("Invalid customer type. Try again.\n");
			}
			else
				isValid = true;
			sc.nextLine();
		}
		return customerType;
	}

	private static double getValidSubtotal(Scanner sc)
	{
		double subtotal = 0.0;
		boolean isValid = false;
		while (isValid == false)
		{
			System.out.print("Enter subtotal:   ");
			if (sc.hasNextDouble())
			{
				subtotal = sc.nextDouble();
				isValid = true;
			}
			else
			{
				sc.next();
				System.out.println("Invalid subtotal entry. Try again.\n");
			}
			if (isValid == true && subtotal <= 0)
			{
				System.out.println("Subtotal must be greater than 0.\n");
				isValid = false;
			}
			else if (isValid == true && subtotal >= 10000)
			{
				System.out.println("Subtotal must be less than 10,000.\n");
				isValid = false;
			}
			sc.nextLine();
		}
		return subtotal;
	}
}