public class ThreadAnimationApp
{

	static int DELAY = 10;

	static ThreadAnimator ta1 = new ThreadAnimator(DELAY, true);
	static ThreadAnimator ta2 = new ThreadAnimator(DELAY, false);

	public static void main(String[] args)

	{
        ta1.start();
        ta2.start();
    }

}


class ThreadAnimator extends Thread
{
	private static int delay;
	private boolean startLeft;

	public ThreadAnimator(int delayTime, boolean startLeft)
	{
		delay = delayTime;
		this.startLeft = startLeft;
	}

	public void run()
	{
		while (true)
		{
			if (startLeft)
			{
				for (int x = 1; x < 75; x++)
					printX(x);

				for (int x = 75; x > 1; x--)
					printX(x);
			}
			else
			{
				for (int x = 75; x > 1; x--)
					printX(x);
				for (int x = 1; x < 75; x++)
					printX(x);
			}
		}
	}

	private static synchronized void printX(int x)
	{
		for (int y = 1; y < x; y ++)
			System.out.print(" ");
		System.out.println("*****");
		try
		{
			sleep(delay);
		}
		catch (InterruptedException e)
		{}
	}

}




