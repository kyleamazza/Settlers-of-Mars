public class DAOFactory
{
    // this method maps the ProductDAO interface
    // to the appropriate data storage mechanism
    public static ProductDAO getProductDAO()
    {
        DAOFile daoFile = new DAOFile();
        String daoName = daoFile.getDAOName();

        ProductDAO pDAO = null;
        if (daoName.equals("ProductTextFile"))
            pDAO = new ProductTextFile();
        else if (daoName.equals("ProductRandomFile"))
            pDAO = new ProductRandomFile();
        return pDAO;
    }
}