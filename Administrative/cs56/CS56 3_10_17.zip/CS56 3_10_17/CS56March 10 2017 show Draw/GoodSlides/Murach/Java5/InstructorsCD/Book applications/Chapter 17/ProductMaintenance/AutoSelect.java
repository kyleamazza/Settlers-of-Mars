import java.awt.event.*;
import javax.swing.*;

public class AutoSelect implements FocusListener
{
	public void focusGained(FocusEvent e)
	{
		if (e.getComponent() instanceof JTextField)
		{
			JTextField t = (JTextField) e.getComponent();
			t.selectAll();
		}
	}

	public void focusLost(FocusEvent e)
	{
	}
}