import java.util.Scanner;

/* This solution reads the input as a string, then parses each one-character substring
 * to an array of type int, where element 0 represents the thousands digit,
 * element 1 is the hundreds digit, element 2 is the tens digit, and element 3 is the
 * ones digit. The parsing routine is complicated by the requirement that
 * the string can be from 1 to 4 characters long. It first calculates the offset into the
 * array represented by the first character in the string based on the string length. For
 * example, if the input is "123" the first character is the hundreds digit, not the tens
 * digit. Therefore the offset is 1.
 *
 * Once the array is filled with the correct integers, the array elements are moved to variable
 * with more meaningful names for clarity. Then, the output string is built by using each digit
 * as an index into the units, teens, or tens array, which provides the words used to build the
 * string.
 */


public class NumberConverterApp{

static Scanner sc = new Scanner(System.in);

    public static void main(String[] args)
    {
        System.out.println("Welcome to the Number to Word Converter.");

        // set up the string arrays
        String[] units = {"one", "two", "three", "four", "five",
                "six", "seven", "eight", "nine"};
        String[] teens = { "ten", "eleven", "twelve", "thirteen", "fourteen",
                "fifteen", "sixteen", "seventeen", "eighteen",
                "nineteen"};
        String[] tens = {"twenty", "thirty", "forty", "fifty",
                    "sixty", "seventy", "eighty", "ninety"};

        // the main loop
        do
        {
            System.out.print("\nEnter the number you want to convert to words: ");
            String numString = sc.nextLine();

            if (numString.length() > 4)
            {
                numString = numString.substring(0,4);
                System.out.println("Input truncated to " + numString);
            }

            int[] num = new int[4];                     // all initialized to zero

            int offset = 4 - numString.length();
            for (int i = 0; i < numString.length(); i++)    // fill each element with the correct digit
                num[i+offset] = Integer.parseInt(numString.substring(i, i+1));

            int onesDigit = num[3];                     // get the ones digit
            int tensDigit = num[2];                     // get the tens digit
            int hundredsDigit = num[1];                 // get the hundreds digit
            int thousandsDigit = num[0];                // get the thousands digit
            String words = "";

            if (thousandsDigit > 0)
                words += units[thousandsDigit - 1] + " thousand ";
            if (hundredsDigit > 0)
                words += units[hundredsDigit - 1] + " hundred ";
            if (tensDigit > 1)                          // numbers ending in 20 - 99
            {
                words += tens[tensDigit - 2] + " ";
                if (onesDigit > 0)
                    words += units[onesDigit - 1];
            }
            else if (tensDigit == 1)                    // numbers ending in 10-19
                words += teens[onesDigit];
            else if (tensDigit == 0)                    // numbers ending in 00 - 09
                if (onesDigit > 0)
                    words += units[onesDigit - 1];

            if (words.length() == 0)                    // all zeros
                words = "zero";

            System.out.println(words + "\n");
        } while (getAnother());

    }



    public static boolean getAnother()
    {
        System.out.print("Convert another number? (y/n): " );
        String choice = sc.nextLine();
        if (choice.equalsIgnoreCase("Y"))
            return true;
        else
            return false;
    }

}



