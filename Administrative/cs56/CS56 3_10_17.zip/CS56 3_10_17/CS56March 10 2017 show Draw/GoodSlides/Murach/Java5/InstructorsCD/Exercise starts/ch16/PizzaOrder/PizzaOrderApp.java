public class PizzaOrderApp
{
    public static void main(String[] args)
    {
    }
}