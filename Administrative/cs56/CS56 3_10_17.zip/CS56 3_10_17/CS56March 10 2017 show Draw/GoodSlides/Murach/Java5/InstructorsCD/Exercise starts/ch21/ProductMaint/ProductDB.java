import java.util.*;
import java.sql.*;

public class ProductDB implements ProductDAO
{
	private Connection connection = null;

	public ProductDB()
	{
		this.connect();  // initializes connection
	}

	private void connect()
	{
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");

			String url = "jdbc:odbc:MurachDB";
			String username = "Admin";
			String password = "";
			connection = DriverManager.getConnection(url, username, password);
		}
		catch(ClassNotFoundException e)
		{
			System.err.println("Database driver not found.");
		}
		catch(SQLException e)
		{
			System.err.println("Error connecting to the database: " + e);
		}
	}

	public ArrayList<Product> getProducts()
	{
		try
		{
			ArrayList<Product> products = new ArrayList<Product>();

			String query = "SELECT ProductCode, Description, Price "
						 + "FROM Products ORDER BY ProductCode ASC";
			PreparedStatement ps = connection.prepareStatement(query);
			ResultSet rs = ps.executeQuery();

			while(rs.next())
			{
				String code = rs.getString("ProductCode");
				String description = rs.getString("Description");
				double price = rs.getDouble("Price");

				Product p = new Product(code, description, price);
				products.add(p);
			}
			rs.close();
			ps.close();
			return products;
		}
		catch(SQLException sqle)
		{
			//sqle.printStackTrace();  // for debugging
			return null;
		}
	}

	public Product getProduct(String code)
	{
		try
		{
			String selectProduct =
				"SELECT ProductCode, Description, Price " +
				"FROM Products " +
				"WHERE ProductCode = ?";
			PreparedStatement ps = connection.prepareStatement(selectProduct);
			ps.setString(1, code);
			ResultSet rs = ps.executeQuery();

			if (rs.next())
			{
				String description = rs.getString("Description");
				double price = rs.getDouble("Price");
				Product p = new Product(code, description, price);
				rs.close();
				ps.close();
				return p;
			}
			else
				return null;
		}
		catch(SQLException sqle)
		{
			//sqle.printStackTrace();	// for debugging
			return null;
		}
	}

	public boolean addProduct(Product p)
	{
		try
		{
			String insert =
				"INSERT INTO Products (ProductCode, Description, Price) " +
				"VALUES (?, ?, ?)";
			PreparedStatement ps = connection.prepareStatement(insert);
			ps.setString(1, p.getCode());
			ps.setString(2, p.getDescription());
			ps.setDouble(3, p.getPrice());
			ps.executeUpdate();
			ps.close();
			return true;
		}
		catch(SQLException sqle)
		{
			//sqle.printStackTrace();	// for debugging
			return false;
		}
	}

	public boolean deleteProduct(Product p)
	{
		try
		{
			String delete =
				"DELETE FROM Products " +
				"WHERE ProductCode = ?";
			PreparedStatement ps = connection.prepareStatement(delete);
			ps.setString(1, p.getCode());
			ps.executeUpdate();
			ps.close();
			return true;
		}
		catch(SQLException sqle)
		{
			//sqle.printStackTrace();	// for debugging
			return false;
		}
	}

	public boolean updateProduct(Product p)
	{
		try
		{
			String update =
				"UPDATE Products SET " +
					"Description = ?, " +
					"Price = ? " +
				"WHERE ProductCode = ?";
			PreparedStatement ps = connection.prepareStatement(update);
			ps.setString(1, p.getDescription());
			ps.setDouble(2, p.getPrice());
			ps.setString(3, p.getCode());
			ps.executeUpdate();
			ps.close();
			return true;
		}
		catch(SQLException sqle)
		{
			//sqle.printStackTrace();	// for debugging
			return false;
		}
	}
}