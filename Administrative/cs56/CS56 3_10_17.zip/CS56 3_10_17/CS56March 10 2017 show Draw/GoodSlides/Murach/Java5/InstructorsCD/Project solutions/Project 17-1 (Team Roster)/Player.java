public class Player
{
	private String lastName;
	private String firstName;
	private int number;

	public Player()

	{
	}

	public Player(String lastName, String firstName, int number)
	{
		this.lastName = lastName;
		this.firstName = firstName;
		this.number = number;
	}

	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	public String getLastName()
	{
		return lastName;
	}

	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	public String getFirstName()
	{
		return firstName;
	}

	public void setNumber(int number)
	{
		this.number = number;
	}

	public int getNumber()
	{
		return this.number;
	}

	public String getNumberString()
	{
		return ((Integer)number).toString();
	}

	public String getFullName()
	{
		return this.firstName + " " + this.lastName;
	}

	public String toString()
	{
		return this.getFullName() + " (" + this.number + ")";
	}

}