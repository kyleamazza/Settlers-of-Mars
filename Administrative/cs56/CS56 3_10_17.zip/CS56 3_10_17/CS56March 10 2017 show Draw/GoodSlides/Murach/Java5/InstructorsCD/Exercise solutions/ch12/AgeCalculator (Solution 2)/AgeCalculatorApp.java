import java.util.*;
import java.text.DateFormat;

public class AgeCalculatorApp
{
    public static void main(String[] args)
    {
        DateFormat shortDate = DateFormat.getDateInstance();
        GregorianCalendar today = new GregorianCalendar();
        int todaysYear = today.get(Calendar.YEAR);

        //Get the user's birthday
        System.out.println("Welcome to the age calculator.");
        Scanner sc = new Scanner(System.in);
        int birthMonth = Validator.getInt(sc, "Enter the month you were born (1 to 12): ",
            0, 13);
        int birthDay = Validator.getInt(sc, "Enter the day of the month you were born: ",
            0, 32);
        int birthYear = Validator.getInt(sc, "Enter the year you were born (four digits): ",
        todaysYear - 111, todaysYear + 1);

        //Create a GregorianCalendar object for the user's birthday and print it
        GregorianCalendar birthDate = new GregorianCalendar(
            birthYear, birthMonth - 1, birthDay);
        System.out.println("Your birth date is " + shortDate.format(birthDate.getTime()));

        //Print the current date
        System.out.println("Today's date is " + shortDate.format(today.getTime()));

        //Calculate and print the user's age
        int age = -1;
        while (today.compareTo(birthDate) > 0)
        {
          birthDate.add(Calendar.YEAR, 1);
          age++;
        }
        System.out.println("Your age is: " + age);

    }
}
