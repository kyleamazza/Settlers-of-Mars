import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class LineupApp
{
    public static void main(String[] args)
    {
        JFrame frame = new LineupFrame();
        frame.setVisible(true);
    }
}

class LineupFrame extends JFrame
{
    public LineupFrame()
    {
        setTitle("Lineup");
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new LineupPanel();
        this.add(panel);
        this.pack();
        centerWindow(this);
    }

    private void centerWindow(Window w)
    {
        Toolkit tk = Toolkit.getDefaultToolkit();
        Dimension d = tk.getScreenSize();
        setLocation((d.width-w.getWidth())/2, (d.height-w.getHeight())/2);
    }
}

class LineupPanel extends JPanel implements ActionListener
{

    private JRadioButton homeRadioButton,				// home and visitor radio buttons
                         visitorRadioButton;

    private JLabel		 teamLabel;						// team label and text field
    private JTextField   teamTextField;

    private JTextField   player1TextField;
	private JComboBox	 player1ComboBox;

    private JTextField   player2TextField;
	private JComboBox	 player2ComboBox;

    private JTextField   player3TextField;
	private JComboBox	 player3ComboBox;

    private JTextField   player4TextField;
	private JComboBox	 player4ComboBox;

    private JTextField   player5TextField;
	private JComboBox	 player5ComboBox;

    private JTextField   player6TextField;
	private JComboBox	 player6ComboBox;

    private JTextField   player7TextField;
	private JComboBox	 player7ComboBox;

    private JTextField   player8TextField;
	private JComboBox	 player8ComboBox;

    private JTextField   player9TextField;
	private JComboBox	 player9ComboBox;

    private JButton      okButton,
                         exitButton;

	public String[] positions = {"Choose a position", "Pitcher", "Catcher", "First Base",
								 "Second Base", "Third Base", "Short Stop",
								 "Left Field", "Center Field", "Right Field" };

	public String[] playerName = new String[9];				// used to store the 9 names
	public String[] playerPos = new String[9];				// the position assigned to each player

    public LineupPanel()
    {

        setLayout(new GridBagLayout());

        Border loweredBorder
            = BorderFactory.createBevelBorder(BevelBorder.LOWERED);

        // team information panel
        JPanel teamPanel = new JPanel();
        ButtonGroup homeGroup = new ButtonGroup();
        teamPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        teamPanel.setBorder(
            BorderFactory.createTitledBorder(loweredBorder,"Team information"));

        // team label
        teamLabel = new JLabel("Team name: ");
        teamPanel.add(teamLabel);

        // team text field
        teamTextField = new JTextField(15);
        teamPanel.add(teamTextField);

        // home radio button
        homeRadioButton = new JRadioButton("Home", true);
        homeRadioButton.addActionListener(this);
        homeGroup.add(homeRadioButton);
        teamPanel.add(homeRadioButton);

        // visitor radio button
        visitorRadioButton = new JRadioButton("Visitor");
        visitorRadioButton.addActionListener(this);
        homeGroup.add(visitorRadioButton);
        teamPanel.add(visitorRadioButton);

        add(teamPanel, getConstraints(0,0,3,1, GridBagConstraints.WEST));

        // player 1 controls
        player1TextField = new JTextField(15);
        player1ComboBox = new JComboBox(positions);
		addPlayerControls(1, player1TextField, player1ComboBox);

        // player 2 controls
        player2TextField = new JTextField(15);
        player2ComboBox = new JComboBox(positions);
		addPlayerControls(2, player2TextField, player2ComboBox);

        // player 3 controls
        player3TextField = new JTextField(15);
        player3ComboBox = new JComboBox(positions);
		addPlayerControls(3, player3TextField, player3ComboBox);

        // player 4 controls
        player4TextField = new JTextField(15);
        player4ComboBox = new JComboBox(positions);
		addPlayerControls(4, player4TextField, player4ComboBox);

        // player 5 controls
        player5TextField = new JTextField(15);
        player5ComboBox = new JComboBox(positions);
		addPlayerControls(5, player5TextField, player5ComboBox);

        // player 6 controls
        player6TextField = new JTextField(15);
        player6ComboBox = new JComboBox(positions);
		addPlayerControls(6, player6TextField, player6ComboBox);

        // player 7 controls
        player7TextField = new JTextField(15);
        player7ComboBox = new JComboBox(positions);
		addPlayerControls(7, player7TextField, player7ComboBox);

        // player 8 controls
        player8TextField = new JTextField(15);
        player8ComboBox = new JComboBox(positions);
		addPlayerControls(8, player8TextField, player8ComboBox);

        // player 9 controls
        player9TextField = new JTextField(15);
        player9ComboBox = new JComboBox(positions);
		addPlayerControls(9, player9TextField, player9ComboBox);

        // button panel
        JPanel buttonPanel = new JPanel();

        // ok button
        okButton = new JButton("OK");
        okButton.addActionListener(this);
        buttonPanel.add(okButton);

        // exit button
        exitButton = new JButton("Exit");
        exitButton.addActionListener(this);
        buttonPanel.add(exitButton);

        add(buttonPanel, getConstraints(2, 12, 1, 1, GridBagConstraints.EAST));

    }

    private void addPlayerControls(int pos, JTextField t, JComboBox c)
    {
		int y = pos + 1;
		JLabel l = new JLabel(pos + ":");
		add(l, getConstraints(0, y, 1, 1, GridBagConstraints.EAST));
		add(t, getConstraints(1, y, 1, 1, GridBagConstraints.WEST));
		add(c, getConstraints(2, y, 1, 1, GridBagConstraints.WEST));
	}

    // a  method for setting grid bag constraints
    private GridBagConstraints getConstraints(int gridx, int gridy,
    int gridwidth, int gridheight, int anchor)
    {
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);
        c.ipadx = 0;
        c.ipady = 0;
        c.gridx = gridx;
        c.gridy = gridy;
        c.gridwidth = gridwidth;
        c.gridheight = gridheight;
        c.anchor = anchor;
        return c;
    }

    public void actionPerformed(ActionEvent e)
    {
        Object source = e.getSource();
        if (source == exitButton)
            System.exit(0);
        else if (source == okButton)
        {
        	playerName[0] = player1TextField.getText();
        	playerPos[0]  = player1ComboBox.getSelectedItem().toString();
        	playerName[1] = player2TextField.getText();
        	playerPos[1]  = player2ComboBox.getSelectedItem().toString();
        	playerName[2] = player3TextField.getText();
        	playerPos[2]  = player3ComboBox.getSelectedItem().toString();
        	playerName[3] = player4TextField.getText();
        	playerPos[3]  = player4ComboBox.getSelectedItem().toString();
        	playerName[4] = player5TextField.getText();
        	playerPos[4]  = player5ComboBox.getSelectedItem().toString();
        	playerName[5] = player6TextField.getText();
        	playerPos[5]  = player6ComboBox.getSelectedItem().toString();
        	playerName[6] = player7TextField.getText();
        	playerPos[6]  = player7ComboBox.getSelectedItem().toString();
        	playerName[7] = player8TextField.getText();
        	playerPos[7]  = player8ComboBox.getSelectedItem().toString();
        	playerName[8] = player9TextField.getText();
        	playerPos[8]  = player9ComboBox.getSelectedItem().toString();

        	displayRoster();
		}

    }

    public void displayRoster()
    {
		String msg = teamTextField.getText();
		if (homeRadioButton.isSelected())
			msg += " (home team)\n";
		else
			msg += " (visiting team)\n";
		for (int i = 0; i < 9; i ++)
			msg += playerName[i] + ", " + playerPos[i] + "\n";
		System.out.println(msg);
	}

}